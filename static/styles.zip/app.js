// ===== 配置 =====
        // 使用後端注入的服務器配置，或回退到當前位置推斷
        const serverConfig = window.SERVER_CONFIG || {
            port: window.location.port || '5000',
            host: window.location.hostname || '127.0.0.1', 
            protocol: window.location.protocol.replace(':', '') || 'http'
        };

        console.log('🔌 使用服務器配置:', serverConfig);

        // 從服務器配置設置 API URL
        let API_URL = serverConfig.api_url || `${serverConfig.protocol}://${serverConfig.host}:${serverConfig.port}`;
        let actualPort = String(serverConfig.port);

        // 備用端口，如果主端口失敗則嘗試
        const possiblePorts = Array.from(new Set([
            String(serverConfig.port), 
            String(window.location.port || '5000'),
            '5000', '5001', '5002'
        ]));

        console.log('🔌 將按順序嘗試端口:', possiblePorts);
        
        // 改進的端口檢測，帶有適當的超時控制
        async function detectAvailablePort() {
            const host = serverConfig.host;
            const protocol = serverConfig.protocol;
            
            for (const port of possiblePorts) {
                try {
                    const testUrl = `${protocol}://${host}:${port}/health`;
                    
                    // 使用 AbortController 實現真正的超時控制
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 1500); // 從 2000ms 改為 1500ms
                    
                    console.log(`🔍 測試端口 ${port}...`);
                    
                    const response = await fetch(testUrl, { 
                        method: 'GET',
                        mode: 'cors',
                        signal: controller.signal
                    });
                    
                    clearTimeout(timeoutId);
                    
                    if (response && response.ok) {
                        actualPort = port;
                        API_URL = `${protocol}://${host}:${port}`;
                        console.log(`✅ 檢測到服務器運行在端口 ${port}`);
                        console.log(`✅ API_URL 更新為: ${API_URL}`);
                        return true;
                    }
                } catch (error) {
                    if (error.name === 'AbortError') {
                        console.log(`⏱️ 端口 ${port} 超時`);
                    } else {
                        console.log(`❌ 端口 ${port} 失敗:`, error.message);
                    }
                    // 繼續嘗試下一個端口
                }
            }
            
            console.warn('⚠️ 無法自動檢測端口,使用默認配置');
            // 🔥 關鍵:即使失敗也返回 false,不拋出錯誤
            return false;
        }
        
        console.log('🔌 嘗試連接端口:', actualPort);
        
        let isConnected = false;
        let lastResponse = '';
        let isInCommandBlock = false;
        let messageCount = 0;
        let currentTypingBubble = null;
        let speechSynthesis = window.speechSynthesis;

        // ===== 核心變數 =====
        let audioQueue = null;
        let sentenceDetector = null;
        let currentMassageSession = null;
        let isAutoListening = false;
        let isMassageSessionActive = false;

        // ===== 按摩對話系統 =====
        const massageDialogues = {
            start: [
                "好喇，而家開始幫您按摩{bodyPart}，力度係{intensity}，請放鬆身體。",
                "準備好未？我哋而家開始{action}{bodyPart}，有咩唔舒服記得話我知。",
                "開始喇！{duration}分鐘嘅{bodyPart}按摩，記得深呼吸放鬆。"
            ],
            check_10: [
                "力度啱唔啱呀？如果太大力或者太輕記得話我知。",
                "開始咗一陣，感覺點呀？需唔需要調整？",
                "有冇唔舒服？力度可以隨時調整架。"
            ],
            check_30: [
                "而家按得點呀？會唔會太大力？",
                "感覺舒唔舒服呀？有需要嘅話我可以調整力度。",
                "繼續保持放鬆，有咩唔妥即刻話我知。"
            ],
            check_50: [
                "過咗一半喇，感覺係咪好咗啲？",
                "中段喇，{bodyPart}有冇鬆啲呀？",
                "做緊一半，力度啱唔啱？需唔需要加強或者減輕？"
            ],
            check_70: [
                "就快完喇，仲有邊度需要加強按摩？",
                "最後階段喇，有冇邊個位特別緊需要多按下？",
                "快完喇，整體感覺點樣？"
            ],
            check_90: [
                "就快完成喇，感覺係咪鬆咗好多？",
                "最後少少，而家感覺舒唔舒服？",
                "快完喇，有冇達到預期效果？"
            ],
            complete: [
                "完成喇！{duration}分鐘嘅{bodyPart}按摩做完，感覺點呀？",
                "好喇，按摩完成！記得多啲休息，飲返杯水。",
                "做完喇！希望您會感到放鬆舒適，有需要隨時搵我。"
            ],
            discomfort: [
                "唔好意思，我即刻調整力度。",
                "明白，我而家減輕啲力度。",
                "收到，我會小心啲。"
            ],
            emergency_stop: [
                "好，即刻停止。您而家感覺點？",
                "明白，已經停咗。有邊度唔舒服？",
                "停咗喇。需唔需要我幫您做啲咩？"
            ]
        };

        // ASR Configuration
        let currentASREngine = 'browser';
        let microphonePermissionGranted = false;

        // Browser Speech Recognition
        let browserRecognition = null;
        let isRecording = false;

        // Server WebSocket for Xunfei
        let serverASRWebSocket = null;
        let audioContext = null;
        let mediaRecorder = null;
        let audioProcessor = null;
        
        // Shared microphone stream
        let sharedMicStream = null;
        let micStreamActive = false;

        // Performance tracking
        let mediaSourceFallbacks = 0;

        // Session workflow state
        let consentGranted = false;
        let consentPromptVisible = false;
        let pendingCommand = null;
        let safetyReminderShown = false;
        let sessionManager = null;
        const INTENSITY_LEVELS = ['輕柔', '適中', '強力'];

        // ===== 極速流式TTS播放器 (修正版) =====
        class UltraFastTTSPlayer {
            constructor() {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                this.audioBuffers = [];
                this.isPlaying = false;
                this.currentSource = null;
                this.nextStartTime = 0;
                this.textBuffer = '';
                this.synthesisQueue = new Map();
                this.sequenceNumber = 0;
                this.playbackIndex = 0;
                this.pendingRequests = 0; // 追蹤進行中的請求
                
                // 調整參數 - 等待更長的文本
                this.minCharsForTTS = 8;    // 至少8個字才開始
                this.maxCharsPerChunk = 50; // 一次最多50字
                this.flushTimeout = null;
                this.lastTextTime = Date.now();
                
                console.log('🚀 Ultra-smooth TTS Player initialized');
            }

            addText(text) {
                this.textBuffer += text;
                this.lastTextTime = Date.now();
                
                // 清除之前的超時
                if (this.flushTimeout) {
                    clearTimeout(this.flushTimeout);
                }
                
                // 檢查是否應該處理
                this._checkAndProcess();
                
                // 設置新的超時（800ms沒有新文本就強制處理）
                this.flushTimeout = setTimeout(() => {
                    this._forceFlush();
                }, 800);
            }

            _checkAndProcess() {
                const endMarks = /[。！？.!?]/;
                let sentenceEnd = -1;

                for (let i = 0; i < this.textBuffer.length; i++) {
                    if (endMarks.test(this.textBuffer[i])) {
                        if (this.textBuffer[i] === '.') {
                            const prev = this.textBuffer[i - 1];
                            const next = this.textBuffer[i + 1];
                            if (prev && next && /\d/.test(prev) && /\d/.test(next)) {
                                continue;
                            }
                        }
                        sentenceEnd = i;
                        break;
                    }
                }

                if (sentenceEnd !== -1) {
                    const sentence = this.textBuffer.substring(0, sentenceEnd + 1);
                    this.textBuffer = this.textBuffer.substring(sentenceEnd + 1);
                    this._processTextChunk(sentence);

                    if (this.textBuffer.length > 0) {
                        this._checkAndProcess();
                    }
                    return;
                }

                // If no sentence end found, check for comma splitting
                if (this.textBuffer.length >= this.maxCharsPerChunk) {
                    const commaIndex = this.textBuffer.lastIndexOf('，', this.maxCharsPerChunk);
                    if (commaIndex > this.minCharsForTTS) {
                        const chunk = this.textBuffer.substring(0, commaIndex + 1);
                        this.textBuffer = this.textBuffer.substring(commaIndex + 1);
                        this._processTextChunk(chunk);
                        return;
                    }
                    
                    // Force split at max length
                    const chunk = this.textBuffer.substring(0, this.maxCharsPerChunk);
                    this.textBuffer = this.textBuffer.substring(this.maxCharsPerChunk);
                    this._processTextChunk(chunk);
                }
            }

            _forceFlush() {
                if (this.textBuffer.length >= this.minCharsForTTS) {
                    const chunk = this.textBuffer;
                    this.textBuffer = '';
                    this._processTextChunk(chunk);
                }
            }

            async _processTextChunk(text) {
                const cleanText = this._cleanTextForTTS(text);
                if (!cleanText || cleanText.length < 2) return;
                
                const sequence = this.sequenceNumber++;
                console.log(`⚡ Processing [${sequence}]: ${cleanText}`);
                
                // 開始播放指示
                if (!this.isPlaying) {
                    this._showIndicator();
                    setFoxState('speaking');
                }
                
                // 並行合成
                this._synthesizeAudio(cleanText, sequence);
            }

            async _synthesizeAudio(text, sequence) {
                this.pendingRequests++; // 增加請求計數
                
                try {
                    const response = await fetch(`${API_URL}/api/tts/stream`, {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-Priority': 'high'
                        },
                        body: JSON.stringify({
                            text: text,
                            voice: document.getElementById('voiceSelect').value,
                            rate: 160,
                            pitch: 100
                        })
                    });

                    if (!response.ok) throw new Error(`TTS failed: ${response.status}`);
                    
                    const arrayBuffer = await response.arrayBuffer();
                    const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
                    
                    // 存儲解碼後的音頻
                    this.synthesisQueue.set(sequence, {
                        buffer: audioBuffer,
                        text: text
                    });
                    
                    console.log(`✅ Synthesized [${sequence}]: ${text.substring(0, 15)}...`);
                    
                    // 開始播放
                    if (!this.isPlaying) {
                        this._startContinuousPlayback();
                    }
                    
                } catch (error) {
                    console.error(`Synthesis error [${sequence}]:`, error);
                    console.log(`TTS Stream failed, falling back to browser speech for chunk: ${text}`);
                    speakText(text); // Fallback to browser TTS
                } finally {
                    this.pendingRequests--; // 減少請求計數
                }
            }

            async _startContinuousPlayback() {
                if (this.isPlaying) return;
                
                this.isPlaying = true;
                this.nextStartTime = this.audioContext.currentTime;
                
                // 開始播放循環
                this._playbackLoop();
            }

            _playbackLoop() {
                if (!this.isPlaying) return;
                
                const audioData = this.synthesisQueue.get(this.playbackIndex);
                
                if (audioData) {
                    // 有音頻可播放
                    console.log(`🔊 Playing [${this.playbackIndex}]: ${audioData.text.substring(0, 15)}...`);
                    
                    const source = this.audioContext.createBufferSource();
                    source.buffer = audioData.buffer;
                    source.connect(this.audioContext.destination);
                    
                    const startTime = Math.max(this.audioContext.currentTime, this.nextStartTime);
                    source.start(startTime);
                    
                    // 更新下一個開始時間（輕微重疊）
                    this.nextStartTime = startTime + audioData.buffer.duration - 0.05;
                    
                    // 清理
                    this.synthesisQueue.delete(this.playbackIndex);
                    this.playbackIndex++;
                    
                    // 繼續下一個
                    setTimeout(() => this._playbackLoop(), 
                        Math.max(50, (audioData.buffer.duration - 0.05) * 1000 * 0.8));
                    
                } else {
                    // 沒有音頻，檢查是否應該繼續等待
                    if (this.pendingRequests > 0 || this.textBuffer.length > 0) {
                        // 還有請求進行中或待處理文本，繼續等待
                        setTimeout(() => this._playbackLoop(), 100);
                    } else if (this.synthesisQueue.size > 0) {
                        // 可能是序號問題，繼續等待
                        setTimeout(() => this._playbackLoop(), 100);
                    } else {
                        // 真的沒有內容了，停止
                        console.log('🛑 Playback stopped - no more content');
                        this._stopPlayback();
                    }
                }
            }

            _stopPlayback() {
                this.isPlaying = false;
                this._hideIndicator();
                setFoxState(null);
            }

            flush() {
                // 清除超時
                if (this.flushTimeout) {
                    clearTimeout(this.flushTimeout);
                    this.flushTimeout = null;
                }
                
                // 強制處理剩餘文本
                this._forceFlush();
            }

            stop() {
                console.log('⏹️ Stopping TTS');
                
                // 清理所有
                if (this.flushTimeout) {
                    clearTimeout(this.flushTimeout);
                }
                
                this.textBuffer = '';
                this.synthesisQueue.clear();
                this.isPlaying = false;
                this.sequenceNumber = 0;
                this.playbackIndex = 0;
                this.pendingRequests = 0;
                
                this._hideIndicator();
                setFoxState(null);
            }

            _cleanTextForTTS(text) {
                // 先做基本清理
                const cleaned = text
                    .replace(/\*+/g, '')
                    .replace(/#+/g, '')
                    .replace(/`+/g, '')
                    .replace(/\[.*?\]\(.*?\)/g, '')
                    .replace(/[_~]/g, '')
                    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
                    .replace(/[\u{1F300}-\u{1F5FF}]/gu, '')
                    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
                    .replace(/[\u{2600}-\u{26FF}]/gu, '')
                    .replace(/[\u{2700}-\u{27BF}]/gu, '')
                    .replace(/[\u{1F900}-\u{1F9FF}]/gu, '')
                    .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '')
                    .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '')
                    .replace(/[\/\\\(\)\[\]{}]/g, ' ')
                    .trim();
                
                // 🔥 最後套用粵語預處理
                return preprocessForCantoneseTTS(cleaned);
            }

            _showIndicator() {
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.add('active');
            }

            _hideIndicator() {
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.remove('active');
            }
        }

        // ===== 優化版音訊播放器 (改進的MediaSource降級) =====
        class OptimizedAudioPlayer {
            constructor() {
                this.queue = [];
                this.cache = new Map();
                this.isPlaying = false;
                this.currentAudio = null;
                this.prefetchInProgress = new Set();
                this.playbackStarted = false;
                
                // MediaSource 支援檢測
                this.mediaSourceSupported = this._detectMediaSourceSupport();
                this.useMediaSource = this.mediaSourceSupported;
                this.fallbackCount = 0;
                
                console.log(`🎵 Audio player initialized (MediaSource: ${this.mediaSourceSupported ? 'Supported' : 'Not Supported'})`);
            }

            _detectMediaSourceSupport() {
                if (!('MediaSource' in window)) {
                    return false;
                }
                
                // 檢測常見格式支援
                const formats = [
                    'audio/mp4; codecs="mp4a.40.2"',
                    'audio/mpeg',
                    'audio/webm; codecs="opus"'
                ];
                
                const supported = formats.some(format => MediaSource.isTypeSupported(format));
                console.log(`🔍 MediaSource format support: ${supported}`);
                return supported;
            }

            async addToQueue(sentence, sentenceIndex) {
                console.log(`🎵 Adding to queue [${sentenceIndex}]: ${sentence.substring(0, 30)}...`);
                this.queue.push({ sentence, sentenceIndex });
                
                // 預載下一句
                if (this.queue.length > 1) {
                    const nextSentence = this.queue[1].sentence;
                    if (!this.cache.has(nextSentence) && !this.prefetchInProgress.has(nextSentence)) {
                        this._prefetch(nextSentence);
                    }
                }
                
                if (!this.isPlaying) {
                    this._playLoop();
                }
            }

            async _prefetch(sentence) {
                if (this.prefetchInProgress.has(sentence)) return;
                
                this.prefetchInProgress.add(sentence);
                try {
                    console.log(`⚡ Prefetching: ${sentence.substring(0, 20)}...`);
                    
                    const cleanText = this._cleanTextForTTS(sentence);
                    if (!cleanText) return;

                    const response = await fetch(`${API_URL}/api/tts/stream`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            text: cleanText,
                            voice: document.getElementById('voiceSelect').value,
                            rate: 160,
                            pitch: 100
                        })
                    });

                    if (response.ok) {
                        const blob = await response.blob();
                        this.cache.set(sentence, blob);
                        console.log(`✅ Prefetch complete: ${sentence.substring(0, 20)}...`);
                    }
                } catch (error) {
                    console.warn(`⚠️ Prefetch failed for: ${sentence.substring(0, 20)}...`, error);
                } finally {
                    this.prefetchInProgress.delete(sentence);
                }
            }

            async _playLoop() {
                if (this.queue.length === 0) {
                    this.isPlaying = false;
                    this.playbackStarted = false;
                    this._hideIndicator();
                    setFoxState(null);
                    return;
                }

                this.isPlaying = true;
                
                if (!this.playbackStarted) {
                    this.playbackStarted = true;
                    this._showIndicator();
                    setFoxState('speaking');
                }
                
                const { sentence, sentenceIndex } = this.queue[0];
                console.log(`🔊 Playing [${sentenceIndex}]: ${sentence.substring(0, 30)}...`);

                this._highlightSentence(sentenceIndex);

                try {
                    // 預載下一句
                    if (this.queue.length > 1) {
                        const nextSentence = this.queue[1].sentence;
                        if (!this.cache.has(nextSentence) && !this.prefetchInProgress.has(nextSentence)) {
                            this._prefetch(nextSentence);
                        }
                    }

                    await this._playSentence(sentence);
                    
                } catch (error) {
                    console.error(`❌ Play error for: ${sentence.substring(0, 20)}...`, error);
                } finally {
                    this.cache.delete(sentence);
                    this.queue.shift();
                    
                    setImmediate(() => this._playLoop());
                }
            }

            async _playSentence(sentence) {
                let audioSource = this.cache.get(sentence);
                
                if (!audioSource) {
                    console.log(`💨 Cache miss, fetching: ${sentence.substring(0, 20)}...`);
                    
                    const cleanText = this._cleanTextForTTS(sentence);
                    if (!cleanText) return;

                    const response = await fetch(`${API_URL}/api/tts/stream`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            text: cleanText,
                            voice: document.getElementById('voiceSelect').value,
                            rate: 160,
                            pitch: 100
                        })
                    });
                    
                    if (!response.ok) {
                        throw new Error(`TTS request failed: ${response.status}`);
                    }
                    
                    // 優化的MediaSource決策
                    const contentType = response.headers.get('content-type') || '';
                    const shouldUseMediaSource = this.useMediaSource && 
                                                this.fallbackCount < 3 && 
                                                contentType.includes('audio/mp4');
                    
                    if (shouldUseMediaSource) {
                        console.log(`🚀 Attempting MediaSource playback`);
                        audioSource = response;
                    } else {
                        console.log(`📦 Using Blob playback (safer)`);
                        audioSource = await response.blob();
                    }
                }

                // 播放音訊
                if (audioSource instanceof Blob) {
                    return this._playWithBlob(audioSource);
                } else if (audioSource instanceof Response) {
                    try {
                        return await this._playWithMediaSource(audioSource);
                    } catch (error) {
                        console.warn('MediaSource failed, falling back to Blob:', error);
                        this.fallbackCount++;
                        mediaSourceFallbacks++;
                        
                        // 顯示降級警告
                        this._showFallbackWarning();
                        
                        // 發送遙測數據
                        fetch(`${API_URL}/api/telemetry`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                type: 'media_source_fallback',
                                data: { error: error.message }
                            })
                        }).catch(() => {});
                        
                        // 重新獲取為Blob
                        const blob = await audioSource.blob();
                        return this._playWithBlob(blob);
                    }
                }
            }

            async _playWithMediaSource(response) {
                return new Promise((resolve, reject) => {
                    const mediaSource = new MediaSource();
                    const audio = new Audio();
                    audio.src = URL.createObjectURL(mediaSource);
                    this.currentAudio = audio;

                    let sourceBuffer = null;
                    let hasStarted = false;
                    let streamEnded = false;
                    const pendingChunks = [];

                    const cleanup = () => {
                        URL.revokeObjectURL(audio.src);
                        if (sourceBuffer && !sourceBuffer.updating) {
                            try {
                                mediaSource.removeSourceBuffer(sourceBuffer);
                            } catch (e) {}
                        }
                    };

                    mediaSource.addEventListener('sourceopen', async () => {
                        try {
                            sourceBuffer = mediaSource.addSourceBuffer('audio/mp4; codecs="mp4a.40.2"');
                            
                            sourceBuffer.addEventListener('updateend', () => {
                                // 處理待處理的數據塊
                                if (pendingChunks.length > 0 && !sourceBuffer.updating) {
                                    const chunk = pendingChunks.shift();
                                    try {
                                        sourceBuffer.appendBuffer(chunk);
                                    } catch (e) {
                                        console.error('Failed to append chunk:', e);
                                        reject(e);
                                    }
                                } else if (streamEnded && pendingChunks.length === 0) {
                                    // 流結束且沒有待處理數據
                                    if (mediaSource.readyState === 'open') {
                                        mediaSource.endOfStream();
                                    }
                                }
                            });

                            const reader = response.body.getReader();
                            
                            const pump = async () => {
                                try {
                                    const { done, value } = await reader.read();
                                    
                                    if (done) {
                                        streamEnded = true;
                                        if (!sourceBuffer.updating && pendingChunks.length === 0) {
                                            mediaSource.endOfStream();
                                        }
                                        return;
                                    }

                                    if (sourceBuffer.updating || pendingChunks.length > 0) {
                                        pendingChunks.push(value);
                                    } else {
                                        try {
                                            sourceBuffer.appendBuffer(value);
                                        } catch (e) {
                                            console.error('Failed to append buffer:', e);
                                            reject(e);
                                            return;
                                        }
                                    }

                                    // 嘗試開始播放
                                    if (!hasStarted && audio.buffered.length > 0) {
                                        hasStarted = true;
                                        audio.play().catch(e => {
                                            console.warn('Auto-play failed:', e);
                                            reject(e);
                                        });
                                    }

                                    pump();
                                } catch (pumpError) {
                                    console.error('Pump error:', pumpError);
                                    reject(pumpError);
                                }
                            };

                            pump();

                        } catch (sourceError) {
                            console.error('SourceBuffer error:', sourceError);
                            reject(sourceError);
                        }
                    });

                    audio.addEventListener('ended', () => {
                        cleanup();
                        resolve();
                    });

                    audio.addEventListener('error', (e) => {
                        console.error('Audio error:', e);
                        cleanup();
                        reject(new Error(`Audio error: ${audio.error?.message || 'Unknown'}`));
                    });

                    mediaSource.addEventListener('error', (e) => {
                        console.error('MediaSource error:', e);
                        cleanup();
                        reject(new Error('MediaSource error'));
                    });

                    // 超時保護
                    setTimeout(() => {
                        if (!hasStarted) {
                            cleanup();
                            reject(new Error('MediaSource timeout'));
                        }
                    }, 5000);
                });
            }

            async _playWithBlob(blob) {
                return new Promise((resolve, reject) => {
                    const audio = new Audio(URL.createObjectURL(blob));
                    this.currentAudio = audio;

                    audio.addEventListener('ended', () => {
                        URL.revokeObjectURL(audio.src);
                        resolve();
                    });

                    audio.addEventListener('error', (e) => {
                        console.error('Blob Audio error:', e);
                        URL.revokeObjectURL(audio.src);
                        reject(e);
                    });

                    audio.play().catch(e => {
                        console.warn('Blob Audio play failed:', e);
                        // 即使播放失敗也繼續
                        resolve();
                    });
                });
            }

            _cleanTextForTTS(text) {
                // 先做基本清理
                const cleaned = text
                    .replace(/\*+/g, '')
                    .replace(/#+/g, '')
                    .replace(/`+/g, '')
                    .replace(/\[.*?\]\(.*?\)/g, '')
                    .replace(/[_~]/g, '')
                    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
                    .replace(/[\u{1F300}-\u{1F5FF}]/gu, '')
                    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
                    .replace(/[\u{2600}-\u{26FF}]/gu, '')
                    .replace(/[\u{2700}-\u{27BF}]/gu, '')
                    .replace(/[\u{1F900}-\u{1F9FF}]/gu, '')
                    .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '')
                    .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '')
                    .replace(/[\/\\\(\)\[\]{}]/g, ' ')
                    .replace(/[!?,.;:]+/g, '，')
                    .replace(/\n+/g, '，')
                    .replace(/\s+/g, ' ')
                    .replace(/^[，。！？；：\s]+|[，。！？；：\s]+$/g, '')
                    .trim();
                
                // 🔥 最後套用粵語預處理
                return preprocessForCantoneseTTS(cleaned);
            }

            _highlightSentence(index) {
                const sentences = document.querySelectorAll('.sentence');
                sentences.forEach((s, i) => {
                    if (i === index) {
                        s.classList.add('sentence-highlight');
                    } else {
                        s.classList.remove('sentence-highlight');
                    }
                });
            }

            stop() {
                console.log('⏹️ Stopping audio player');
                this.queue = [];
                this.cache.clear();
                this.prefetchInProgress.clear();
                this.isPlaying = false;
                this.playbackStarted = false;
                
                if (this.currentAudio) {
                    this.currentAudio.pause();
                    this.currentAudio = null;
                }
                this._hideIndicator();
                setFoxState(null);
            }

            _showIndicator() {
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.add('active');
            }

            _hideIndicator() {
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.remove('active');
            }

            _showFallbackWarning() {
                const warning = document.getElementById('fallbackWarning');
                if (warning) {
                    warning.classList.add('show');
                    setTimeout(() => {
                        warning.classList.remove('show');
                    }, 3000);
                }
            }
        }

        // ===== 智能分句器 =====
        class SmartSentenceDetector {
            constructor() {
                this.buffer = '';
                this.sentences = [];
                this.MAX_BUFFER = 60;
                this.MIN_SENTENCE = 8;
                this.QUICK_CUT = /[，,；;]/;
                this.sentenceCount = 0;
                this.processedText = '';
                this.lastUpdateTime = Date.now();
                this.idleFlushInterval = null;
            }

            addText(text) {
                this.buffer += text;
                this.lastUpdateTime = Date.now();
                this.startIdleCheck();
                return this.processSentences();
            }

            startIdleCheck() {
                if (!this.idleFlushInterval) {
                    this.idleFlushInterval = setInterval(() => {
                        this.flushIfIdle();
                    }, 800);
                }
            }

            stopIdleCheck() {
                if (this.idleFlushInterval) {
                    clearInterval(this.idleFlushInterval);
                    this.idleFlushInterval = null;
                }
            }

            flushIfIdle() {
                const idleTime = Date.now() - this.lastUpdateTime;
                if (idleTime > 1500 && this.buffer.trim().length >= this.MIN_SENTENCE) {
                    console.log(`🔄 Idle flush triggered after ${idleTime}ms`);
                    return this.flush();
                }
                return [];
            }

            flush() {
                const res = splitSentencesRespectDecimal(this.buffer, this.MIN_SENTENCE);
                const merged = joinBrokenTemperatureSentences([
                    ...res.sentences,
                    res.tail.trim()
                ].filter(Boolean));
                
                this.buffer = '';
                this.stopIdleCheck();
                
                if (merged.length > 0) {
                    this.sentences.push(...merged);
                    
                    // Add to TTS queue if auto-speak is enabled
                    merged.forEach(sentence => {
                        if (document.getElementById('autoSpeak').checked) {
                            audioQueue.addToQueue(sentence, this.sentenceCount);
                            this.sentenceCount++;
                        }
                    });
                    
                    console.log(`📝 Flushed ${merged.length} sentences:`, merged.map(s => s.substring(0, 20) + '...'));
                }
                
                return merged;
            }

            processSentences() {
                const newSentences = [];
                
                // 1) 先用不會把小數點當句號的切句器
                const result = splitSentencesRespectDecimal(this.buffer, this.MIN_SENTENCE);
                let pieces = result.sentences;
                
                // 2) 把被切斷的 31. / 攝氏5度 這類片段黏回去
                pieces = joinBrokenTemperatureSentences(pieces);
                
                if (pieces.length) {
                    newSentences.push(...pieces);
                    this.sentences.push(...pieces);
                }
                this.buffer = result.tail;

                // 3) 下面是原本的「快速切逗號 / 強制切割」策略
                if (this.buffer.length > 15) {
                    const commaMatch = this.buffer.match(this.QUICK_CUT);
                    if (commaMatch && commaMatch.index >= 15) {
                        const sentence = this.buffer.substring(0, commaMatch.index + 1).trim();
                        if (sentence.length >= this.MIN_SENTENCE) {
                            newSentences.push(sentence);
                            this.sentences.push(sentence);
                            this.buffer = this.buffer.substring(commaMatch.index + 1);
                        }
                    }
                    else if (this.buffer.length > this.MAX_BUFFER) {
                        // 取 0~50 的 substring 之前，避免切在「數字.數字」中間
                        let cut = 50;
                        const look = this.buffer.substring(0, cut + 2); // 多看兩個字元
                        
                        // 若在 cut-1 位置有 '.' 且 cut-2 / cut 是數字 → 把 cut 往後挪一點
                        if (/\d\.\d/.test(look.slice(cut - 2, cut + 1))) {
                            const nextEnd = look.slice(cut + 1).search(/[。！？!?]/);
                            if (nextEnd !== -1) {
                                cut += nextEnd + 1;
                            }
                        }
                        
                        const forcedSentence = this.buffer.substring(0, cut).trim();
                        if (forcedSentence.length >= this.MIN_SENTENCE) {
                            newSentences.push(forcedSentence);
                            this.sentences.push(forcedSentence);
                            this.buffer = this.buffer.substring(cut);
                        }
                    }
                }

                // Add to TTS queue
                newSentences.forEach(sentence => {
                    if (document.getElementById('autoSpeak').checked) {
                        audioQueue.addToQueue(sentence, this.sentenceCount);
                        this.sentenceCount++;
                    }
                });

                if (newSentences.length > 0) {
                    console.log(`📝 Generated ${newSentences.length} sentences:`, newSentences.map(s => s.substring(0, 20) + '...'));
                }

                return newSentences;
            }

            reset() {
                this.buffer = '';
                this.sentences = [];
                this.sentenceCount = 0;
                this.processedText = '';
                this.lastUpdateTime = Date.now();
                this.stopIdleCheck();
                console.log('🔄 Sentence detector reset');
            }
        }

        // ===== Speech Recognition Functions =====
        let audioLevelDetector = null;
        let wakeWordDetector = null;

        let recognitionMode = 'idle'; // idle, wake-word, recording

        // New function to calibrate microphone
        async function calibrateMicrophone() {
            const infoEl = document.getElementById('micCalibrationInfo');
            const origText = infoEl.textContent;
            infoEl.textContent = '請保持安靜，正在校準中...';

            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const analyser = audioContext.createAnalyser();
                const microphone = audioContext.createMediaStreamSource(stream);
                microphone.connect(analyser);

                analyser.fftSize = 256;
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                
                let measurements = [];
                const calibrationDuration = 5000; // 5 seconds
                const sampleInterval = 100; // every 100ms

                const sampler = setInterval(() => {
                    analyser.getByteFrequencyData(dataArray);
                    const average = dataArray.reduce((a, b) => a + b) / bufferLength;
                    measurements.push(average);
                }, sampleInterval);

                setTimeout(() => {
                    clearInterval(sampler);
                    stream.getTracks().forEach(track => track.stop());
                    audioContext.close();

                    if (measurements.length > 0) {
                        const ambientNoise = measurements.reduce((a, b) => a + b) / measurements.length;
                        const newThreshold = ambientNoise * 1.5 + 10; // Heuristic: 1.5x ambient noise + a constant
                        localStorage.setItem('volumeThreshold', newThreshold.toFixed(2));
                        infoEl.textContent = `校準完成！新靈敏度閾值: ${newThreshold.toFixed(2)}`;
                        console.log(`🎤 Microphone calibrated. Ambient noise: ${ambientNoise.toFixed(2)}, New threshold: ${newThreshold.toFixed(2)}`);
                        saveSettings();
                    } else {
                        infoEl.textContent = '校準失敗，請重試。';
                    }

                    setTimeout(() => { infoEl.textContent = origText; }, 4000);

                }, calibrationDuration);

            } catch (error) {
                console.error("Microphone calibration failed:", error);
                infoEl.textContent = '無法訪問麥克風，校準失敗。';
                setTimeout(() => { infoEl.textContent = origText; }, 4000);
            }
        }

        function initBrowserSpeechRecognition() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                console.error("Speech Recognition API is not supported in this browser.");
                return;
            }

            browserRecognition = new SpeechRecognition();
            browserRecognition.continuous = true;
            browserRecognition.interimResults = true;
            browserRecognition.lang = 'yue-Hant-HK';

            // CORRECT: Declare transcript variables here, outside onresult
            let finalTranscript = '';
            let confidenceTimeout = null;

            browserRecognition.onstart = () => {
                // The isRecording flag is set by the calling function (startRecording or startAutoVoiceListening)
                const voiceButton = document.getElementById('voiceButton');
                if (!isAutoListening) { // Only show recording UI for manual recording
                    if (voiceButton) voiceButton.classList.add('recording');
                    updateVoiceHint('錄音中...', '#ff3838');
                    setFoxState('listening');
                }
            };

            browserRecognition.onend = () => {
                console.log('🛑 Browser recognition ended');
                
                if (!isAutoListening) {
                    // Normal recording ended
                    isRecording = false;
                    if (audioLevelDetector) {
                        audioLevelDetector.stop();
                        audioLevelDetector = null;
                    }
                    const voiceButton = document.getElementById('voiceButton');
                    if (voiceButton) voiceButton.classList.remove('recording');
                    updateVoiceHint('按住說話');
                    setFoxState(null);
                    
                    const userInput = document.getElementById('userInput');
                    if (userInput && userInput.value.trim()) {
                        sendMessage();
                    }
                } else if (isMassageSessionActive) {
                    // If continuous listening stops during a massage, restart it.
                    console.log("🔄 Continuous recognition ended unexpectedly, restarting...");
                    setTimeout(() => {
                        try {
                            if (isMassageSessionActive) browserRecognition.start();
                        } catch(e) {
                            console.error("Error auto-restarting recognition", e);
                        }
                    }, 500); // 500ms delay to prevent rapid-fire restarts
                }
                
                // Reset for the next recognition
                finalTranscript = '';

                // Ensure wake word restarts if enabled and we are not in another recording session
                setTimeout(() => {
                    const wakeWordToggle = document.getElementById('wakeWordToggle');
                    if (wakeWordDetector && wakeWordToggle?.checked && !isAutoListening && !isRecording) {
                        console.log("🔄 Restarting wake word detection after recognition ended...");
                        if (!wakeWordDetector.isListening) {
                           wakeWordDetector.start();
                        }
                    }
                }, 800); // Delay to prevent immediate restart conflicts
            };

            browserRecognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                isRecording = false;
                isAutoListening = false; // Also reset this flag on error
                if (audioLevelDetector) {
                    audioLevelDetector.stop();
                    audioLevelDetector = null;
                }
                const voiceButton = document.getElementById('voiceButton');
                if (voiceButton) voiceButton.classList.remove('recording', 'auto-listening');
                updateVoiceHint('按住說話');
                setFoxState(null);
                hideListeningIndicator();
            };

            browserRecognition.onresult = (event) => {
                let interimTranscript = '';
                
                // Use the parent-scoped finalTranscript to accumulate results
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                // 🎤 If in auto-listening mode, process immediately
                if (isAutoListening && currentMassageSession) {
                    if (finalTranscript) { // Process the accumulated final transcript
                        currentMassageSession.processVoiceResponse(finalTranscript);
                        finalTranscript = ''; // Reset after processing
                    }
                } else {
                    // This is for normal "hold-to-talk" recording
                    const userInput = document.getElementById('userInput');
                    if (userInput) {
                        userInput.value = finalTranscript + interimTranscript;
                    }

                    // Check for submission conditions (punctuation or high confidence)
                    const latestResult = event.results[event.results.length - 1];
                    if (latestResult.isFinal) {
                        const confidence = latestResult[0].confidence;
                        const endPunctuations = /[。！？啦喇呀咩囉喎]/;
                        const confidenceTimeoutDuration = parseInt(document.getElementById('confidenceTimeoutSlider').value) || 800;

                        if (endPunctuations.test(finalTranscript)) {
                            console.log('✅ Punctuation detected: submitting.');
                            stopRecording();
                        } else if (confidence > 0.8) {
                            if (confidenceTimeout) clearTimeout(confidenceTimeout);
                            confidenceTimeout = setTimeout(() => {
                                console.log('✅ High confidence: submitting.');
                                stopRecording();
                            }, confidenceTimeoutDuration);
                        }
                    }
                }
            };
        }

        async function startRecording() {
            // Block manual recording during an active massage session
            if (isMassageSessionActive) {
                console.log("🎤 Manual recording is disabled during massage session.");
                showFoxReaction('listening', 1500); // Show that it's already listening
                return;
            }

            // If a massage session is active, pressing the mic button
            // should trigger the session's listening mode.
            if (currentMassageSession && !currentMassageSession.isWaitingForResponse) {
                console.log("🎤 Manually triggering massage session voice listening.");
                await currentMassageSession.activateVoiceListening();
                return; // Exit to not start a manual recording
            }

            if (isRecording || isAutoListening) {
                console.log(`[ASR] startRecording aborted. isRecording: ${isRecording}, isAutoListening: ${isAutoListening}`);
                return;
            }
            console.log('[ASR] Starting manual recording...');
            isRecording = true;

            if (wakeWordDetector && wakeWordDetector.isListening) {
                wakeWordDetector.stop();
                await new Promise(resolve => setTimeout(resolve, 250));
            }

            if (!browserRecognition) {
                initBrowserSpeechRecognition();
            }

            try {
                document.getElementById('userInput').value = '';
                browserRecognition.start();
            } catch (error) {
                console.error("[ASR] Could not start recording:", error);
                isRecording = false; // Reset flag on error
            }
        }

        function stopRecording() {
            // Block manual stop during an active massage session
            if (isMassageSessionActive) {
                return;
            }

            // If a massage session is active and listening, releasing the button should stop it.
            if (currentMassageSession && currentMassageSession.isWaitingForResponse) {
                console.log("🎤 Manually stopping massage session voice listening.");
                currentMassageSession.cancelVoiceListening();
                return; // Exit to not stop a manual recording
            }

            if (!isRecording) return;
            console.log('🛑 Stopping manual recording...');
            if (browserRecognition) {
                // The onend event handler will set isRecording = false and handle other cleanup
                browserRecognition.stop();
            }
        }
        // ===== Wake Word Detector (改進版) =====
        class WakeWordDetector {
            constructor() {
                this.recognition = null;
                this.isListening = false;
                this.wakeWord = "護理員";
                this.wakeWordDetected = false;
                this.errorBackoff = 1000;
                this.maxBackoff = 5000; // ✅ 降低最大退避時間：從30秒改為5秒
                this.lastActivityTime = Date.now();
                this.healthCheckInterval = null;
                this.restartAttempts = 0;
                this.maxRestartAttempts = 3;
            }

            init() {
                const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                if (!SpeechRecognition) {
                    console.error("Speech Recognition API is not supported in this browser.");
                    return false;
                }

                this.recognition = new SpeechRecognition();
                this.recognition.continuous = true;
                this.recognition.interimResults = true;
                this.recognition.lang = 'yue-Hant-HK';

                this.recognition.onresult = (event) => {
                    // ✅ 重置錯誤退避和活動時間
                    this.errorBackoff = 1000;
                    this.lastActivityTime = Date.now();
                    this.restartAttempts = 0;
                    
                    const wakeWordRegex = new RegExp(this.wakeWord.replace(/ /g, '\\s*'));
                    let interimTranscript = '';
                    
                    for (let i = event.resultIndex; i < event.results.length; ++i) {
                        const transcript = event.results[i][0].transcript;
                        console.log(`🎤 Wake word listening: "${transcript}"`); // ✅ 添加調試日誌
                        
                        if (event.results[i].isFinal) {
                            if (wakeWordRegex.test(transcript)) {
                                this.onWakeWordDetected();
                            }
                        } else {
                            interimTranscript += transcript;
                            if (wakeWordRegex.test(interimTranscript)) {
                                this.onWakeWordDetected();
                            }
                        }
                    }
                };

                this.recognition.onend = () => {
                    console.log(`🎤 Wake word service ended. isListening: ${this.isListening}`);
                    
                    if (this.isListening) {
                        // ✅ 限制重啟次數，防止無限循環
                        if (this.restartAttempts < this.maxRestartAttempts) {
                            this.restartAttempts++;
                            console.log(`🔄 Restarting wake word (attempt ${this.restartAttempts}/${this.maxRestartAttempts}) in ${this.errorBackoff / 1000}s...`);
                            setTimeout(() => this._internalStart(), this.errorBackoff);
                        } else {
                            console.warn('⚠️ Max restart attempts reached. Stopping wake word detection.');
                            this.isListening = false;
                            // ✅ 5秒後重置並嘗試重新開始
                            setTimeout(() => {
                                this.restartAttempts = 0;
                                this.errorBackoff = 1000;
                                if (document.getElementById('wakeWordToggle')?.checked) {
                                    console.log('🔄 Resetting and restarting wake word detection...');
                                    this.start();
                                }
                            }, 5000);
                        }
                    }
                };

                this.recognition.onerror = (event) => {
                    console.error('❌ Speech recognition error:', event.error);
                    
                    // ✅ 根據錯誤類型處理
                    if (event.error === 'no-speech') {
                        // 沒有語音不算錯誤，重置退避
                        this.errorBackoff = 1000;
                    } else if (event.error === 'aborted') {
                        // 被中止，可能是正常停止
                        this.errorBackoff = 1000;
                    } else {
                        // 其他錯誤才增加退避時間
                        this.errorBackoff = Math.min(this.errorBackoff * 1.5, this.maxBackoff);
                    }
                };

                // ✅ 啟動健康檢查
                this.startHealthCheck();

                return true;
            }

            // ✅ 內部啟動方法，避免重複重置標誌
            _internalStart() {
                try {
                    this.recognition.start();
                    console.log("✅ Wake word recognition started internally");
                } catch (error) {
                    console.error("❌ Failed to start wake word recognition:", error);
                    // 如果啟動失敗，稍後再試
                    if (this.isListening) {
                        setTimeout(() => this._internalStart(), 2000);
                    }
                }
            }

            start() {
                if (this.isListening) {
                    console.log("⚠️ Wake word already listening");
                    return;
                }
                
                this.isListening = true;
                this.wakeWordDetected = false;
                this.errorBackoff = 1000;
                this.restartAttempts = 0;
                this.lastActivityTime = Date.now();
                
                try {
                    this.recognition.start();
                    console.log("🎤 Wake word listening started...");
                } catch (error) {
                    console.error("❌ Could not start wake word listening:", error);
                    this.isListening = false;
                    
                    // ✅ 如果啟動失敗，2秒後重試
                    setTimeout(() => {
                        if (document.getElementById('wakeWordToggle')?.checked) {
                            console.log("🔄 Retrying wake word start...");
                            this.start();
                        }
                    }, 2000);
                }
            }

            stop() {
                if (!this.isListening) return;
                
                this.isListening = false;
                this.wakeWordDetected = false;
                
                try {
                    this.recognition.stop();
                    console.log("🛑 Wake word listening stopped.");
                } catch (error) {
                    console.error("❌ Error stopping wake word:", error);
                }
                
                // ✅ 停止健康檢查
                this.stopHealthCheck();
            }

            onWakeWordDetected() {
                if (this.wakeWordDetected) {
                    console.log("⚠️ Wake word already detected, ignoring duplicate");
                    return;
                }
                
                this.wakeWordDetected = true;
                console.log("🦊 Wake word detected!");
                showFoxReaction('listening', 1500);
                
                if (typeof startRecording === 'function') {
                    this.stop();
                    startRecording();
                }
            }

            // ✅ 健康檢查：每5秒檢查一次
            startHealthCheck() {
                this.stopHealthCheck(); // 先清除舊的
                
                this.healthCheckInterval = setInterval(() => {
                    if (!this.isListening) return;
                    
                    const timeSinceActivity = Date.now() - this.lastActivityTime;
                    
                    // 如果超過30秒沒有活動，可能卡住了
                    if (timeSinceActivity > 30000) {
                        console.warn('⚠️ Wake word detector seems stuck. Restarting...');
                        this.restart();
                    }
                }, 5000);
            }

            stopHealthCheck() {
                if (this.healthCheckInterval) {
                    clearInterval(this.healthCheckInterval);
                    this.healthCheckInterval = null;
                }
            }

            // ✅ 強制重啟
            restart() {
                console.log('🔄 Force restarting wake word detector...');
                const wasListening = this.isListening;
                
                try {
                    this.stop();
                } catch (e) {
                    console.error('Error during stop:', e);
                }
                
                if (wasListening && document.getElementById('wakeWordToggle')?.checked) {
                    setTimeout(() => {
                        this.start();
                    }, 1000);
                }
            }
        }

        // ===== Interactive Massage Session =====

        class InteractiveMassageSession {
            constructor(command) {
                this.command = command;
                this.duration = command.duration * 60 * 1000; // Convert to ms
                this.startTime = Date.now();
                this.checkInPoints = [10, 30, 50, 70, 90]; // Percentage points
                this.completedCheckIns = new Set();
                this.userResponses = [];
                this.progressInterval = null;
            }
            
            start() {
                isMassageSessionActive = true;
                console.log('🎯 Massage session started - Continuous listening enabled.');
                
                createEmergencyStopButton();

                this.createProgressBar();
                this.progressInterval = setInterval(() => {
                    this.checkProgress();
                }, 1000);

                // Start continuous listening for the session
                startContinuousMassageListening();
                
                const startDialogue = randomChoice(massageDialogues.start)
                    .replace('{bodyPart}', this.command.bodyPart || '身體')
                    .replace('{intensity}', this.command.intensity || '適中')
                    .replace('{action}', this.command.action || '按摩')
                    .replace('{duration}', this.command.duration || '5');
                
                updateProgressWithDialogue(0, startDialogue);
            }

            createProgressBar() {
                const responseBox = document.getElementById('responseBox');
                
                // Remove old one if exists
                const oldProgress = document.getElementById('massageProgress');
                if(oldProgress) oldProgress.remove();

                const progressDiv = document.createElement('div');
                progressDiv.id = 'massageProgress';
                progressDiv.style.cssText = `
                    margin-top: 20px;
                    padding: 15px;
                    background: linear-gradient(135deg, rgba(74, 144, 226, 0.1), rgba(126, 217, 195, 0.1));
                    border-radius: 12px;
                    border: 1px solid var(--tech-border);
                `;
                
                progressDiv.innerHTML = `
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-weight: 600; color: var(--medical-blue-dark);">⏳ 按摩進行中</span>
                        <span id="progressTime" style="font-weight: 600; color: var(--primary-color);">0:00 / ${this.command.duration}:00</span>
                    </div>
                    <div style="width: 100%; height: 8px; background: rgba(74, 144, 226, 0.2); border-radius: 4px; overflow: hidden;">
                        <div id="progressBarFill" style="height: 100%; background: linear-gradient(90deg, var(--primary-color), var(--secondary-color)); width: 0%; transition: width 0.3s;"></div>
                    </div>
                `;
                
                responseBox.appendChild(progressDiv);
            }
            
            checkProgress() {
                const elapsed = Date.now() - this.startTime;
                let progress = (elapsed / this.duration) * 100;
                if (progress >= 100) {
                    progress = 100;
                    this.stop();
                    return; // Stop further checks
                }

                // Update progress bar
                const progressBarFill = document.getElementById('progressBarFill');
                if(progressBarFill) progressBarFill.style.width = progress + '%';

                // Update time display
                const elapsedMinutes = Math.floor(elapsed / 60000);
                const elapsedSeconds = Math.floor((elapsed % 60000) / 1000);
                const totalMinutes = this.command.duration;
                const timeDisplay = document.getElementById('progressTime');
                if (timeDisplay) {
                    timeDisplay.textContent = `${elapsedMinutes}:${elapsedSeconds.toString().padStart(2, '0')} / ${totalMinutes}:00`;
                }
                
                // Trigger check-ins at specific points
                this.checkInPoints.forEach(point => {
                    if (progress >= point && !this.completedCheckIns.has(point)) {
                        this.triggerCheckIn(point);
                        this.completedCheckIns.add(point);
                    }
                });
            }
            
            async triggerCheckIn(point) {
                const dialogueKey = `check_${point}`;
                if (!massageDialogues[dialogueKey]) return;

                const dialogue = randomChoice(massageDialogues[dialogueKey])
                    .replace('{bodyPart}', this.command.bodyPart || '身體');
                
                // Speak the question (this will pause/resume listening)
                await speakNurseResponse(dialogue);
            }
            
            async processVoiceResponse(transcript) {
                console.log('🎤 Received voice response during massage:', transcript);
                this.userResponses.push(transcript);
                
                // Process the response
                await handleMidSessionResponse(transcript);
                
                console.log('✅ Massage response processed.');
            }

            stop() {
                removeEmergencyStopButton();

                isMassageSessionActive = false;
                console.log('🛑 Massage session stopped - Continuous listening disabled.');
                
                // Stop continuous listening
                stopContinuousMassageListening();

                if (this.progressInterval) {
                    clearInterval(this.progressInterval);
                    this.progressInterval = null;
                }
                const completeDialogue = randomChoice(massageDialogues.complete)
                    .replace('{duration}', this.command.duration)
                    .replace('{bodyPart}', this.command.bodyPart);
                
                updateProgressWithDialogue(100, completeDialogue);
                
                // Hide controls after session ends
                setTimeout(() => {
                    const controls = document.querySelector('.massage-controls-panel');
                    if(controls) controls.style.display = 'none';
                    hideQuickResponseButtons();
                    const liveControls = document.querySelector('.live-controls');
                    if(liveControls) liveControls.style.display = 'none';
                }, 5000);

                currentMassageSession = null;
            }

            emergencyStop() {
                console.log("🛑 EMERGENCY STOP TRIGGERED 🛑");
                
                removeEmergencyStopButton();

                if (this.progressInterval) {
                    clearInterval(this.progressInterval);
                    this.progressInterval = null;
                }

                stopAllAudio();
                stopContinuousMassageListening();
                sendRobotCommand('stop');

                isMassageSessionActive = false;
                currentMassageSession = null;

                addSystemMessage('⛔ 緊急停止！按摩已立即中止。', 'error');
                
                const controls = document.querySelector('.massage-controls-panel');
                if(controls) controls.style.display = 'none';
                hideQuickResponseButtons();
                const liveControls = document.querySelector('.live-controls');
                if(liveControls) liveControls.style.display = 'none';
                
                const progressDiv = document.getElementById('massageProgress');
                if (progressDiv) progressDiv.remove();
            }
        }

        async function startContinuousMassageListening() {
            if (isAutoListening) return;
            console.log('🎤 Starting continuous listening for massage session...');
            
            // Stop any other recognition first
            if (isRecording) {
                stopRecording();
                await new Promise(resolve => setTimeout(resolve, 250));
            }
            if (wakeWordDetector && wakeWordDetector.isListening) {
                wakeWordDetector.stop();
                await new Promise(resolve => setTimeout(resolve, 250));
            }
            
            if (!browserRecognition) {
                initBrowserSpeechRecognition();
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
            try {
                isAutoListening = true;
                browserRecognition.start();
                showListeningIndicator("聆聽中..."); // Show a persistent indicator
            } catch (error) {
                console.error('❌ Continuous listening failed to start:', error);
                isAutoListening = false;
                hideListeningIndicator();
            }
        }

        function stopContinuousMassageListening() {
            if (!isAutoListening) return;
            console.log('🎤 Stopping continuous listening for massage session...');
            isAutoListening = false;
            
            if (browserRecognition) {
                try {
                    browserRecognition.stop();
                } catch (e) {
                    console.warn('⚠️ Error stopping continuous recognition:', e);
                }
            }
            hideListeningIndicator();
        }

        function showListeningIndicator(message = "正在聆聽...") {
            const indicator = document.getElementById('autoListeningIndicator');
            if (indicator) {
                indicator.innerHTML = `
                    <div class="listening-animation">
                        <span class="listening-dot"></span>
                        <span class="listening-dot"></span>
                        <span class="listening-dot"></span>
                    </div>
                    <span class="listening-text">${message}</span>
                `;
                indicator.style.display = 'flex';
            }
        }

        function hideListeningIndicator() {
            const indicator = document.getElementById('autoListeningIndicator');
            if (indicator) {
                indicator.style.display = 'none';
            }
        }

        // This function is no longer needed for massage sessions but might be called from elsewhere.
        function cancelCurrentListening() {
            if (currentMassageSession) {
                // In the new model, we don't manually cancel.
            } else {
                stopAutoVoiceListening(); // Keep for non-massage contexts if any
            }
        }

        // 🎤 NEW: Handle mid-session user response
        async function handleMidSessionResponse(userInput) {
            const input = userInput.toLowerCase();
            
            if (input.includes('太大力') || input.includes('痛') || input.includes('唔舒服')) {
                await adjustIntensity('lighter');
                speakNurseResponse(randomChoice(massageDialogues.discomfort));
            }
            else if (input.includes('停') || input.includes('唔要')) {
                if(currentMassageSession) {
                    currentMassageSession.stop();
                }
                speakNurseResponse(randomChoice(massageDialogues.emergency_stop));
            }
            else if (input.includes('大力') || input.includes('加強')) {
                await adjustIntensity('stronger');
                speakNurseResponse("好，我加大啲力度。");
            }
            else if (input.includes('好') || input.includes('啱') || input.includes('舒服')) {
                speakNurseResponse("好！咁就繼續啦。");
            } else {
                // If the response is not a clear command, just acknowledge and continue
                speakNurseResponse("收到，我哋繼續按摩。");
            }
        }

        // 🎤 NEW: Update UI with dialogue
        async function updateProgressWithDialogue(progress, message) {
            const progressDiv = document.getElementById('massageProgress');
            
            if(progressDiv) {
                const progressBarFill = progressDiv.querySelector('#progressBarFill');
                if(progressBarFill) progressBarFill.style.width = progress + '%';
            }
            
            const dialogueBubble = document.createElement('div');
            dialogueBubble.className = 'nurse-dialogue-bubble message-bubble visible';
            dialogueBubble.innerHTML = `
                <div class="nurse-avatar">👩‍⚕️</div>
                <div class="dialogue-text">${message}</div>
            `;
            
            const responseBox = document.getElementById('responseBox');
            responseBox.appendChild(dialogueBubble);
            responseBox.scrollTop = responseBox.scrollHeight;
            
            // ✅ Use fixed speakNurseResponse which will use server TTS during massage
            await speakNurseResponse(message);
        }

        // Speak response as nurse
        async function speakNurseResponse(text) {
            if (!document.getElementById('autoSpeak').checked) {
                return;
            }
            
            const cleanText = preprocessForCantoneseTTS(stripHTML(text));
            
            // ✅ During massage session, ALWAYS use server TTS (never browser fallback)
            if (isMassageSessionActive) {
                console.log('🎤 Massage session: Using server TTS');
                await playCantoneseTTS(cleanText);
                return;
            }
            
            // Normal mode: Use UltraFastTTS or fallback
            if (window.ultraFastTTS && typeof window.ultraFastTTS.addText === 'function') {
                window.ultraFastTTS.addText(cleanText);
            } else if (audioQueue && typeof audioQueue.addText === 'function') {
                audioQueue.addText(cleanText);
            } else {
                // Only use browser TTS as last resort (not during massage)
                console.warn('⚠️ Using browser TTS fallback');
                speakText(cleanText);
            }
        }

        function showQuickResponseButtons() {
            const buttons = document.querySelector('.quick-response-buttons');
            if(buttons) buttons.style.display = 'flex';
        }

        function hideQuickResponseButtons() {
            const buttons = document.querySelector('.quick-response-buttons');
            if(buttons) buttons.style.display = 'none';
        }
        
        async function adjustIntensity(direction) {
            const intensityDisplay = document.getElementById('currentIntensityDisplay');
            if (!intensityDisplay) return;

            const currentIndex = INTENSITY_LEVELS.indexOf(intensityDisplay.textContent.replace('當前：', ''));
            let newIndex = currentIndex;

            if (direction === 'lighter' && currentIndex > 0) {
                newIndex--;
            } else if (direction === 'stronger' && currentIndex < INTENSITY_LEVELS.length - 1) {
                newIndex++;
            }
            
            if (newIndex !== currentIndex) {
                const newIntensity = INTENSITY_LEVELS[newIndex];
                intensityDisplay.textContent = `當前：${newIntensity}`;
                if(currentMassageSession) {
                    currentMassageSession.command.intensity = newIntensity;
                }
                console.log(`Intensity changed to: ${newIntensity}`);
            }
        }

        function randomChoice(arr) {
            return arr[Math.floor(Math.random() * arr.length)];
        }

        // ===== Audio Level Detector =====
        class AudioLevelDetector {
            constructor() {
                this.audioContext = null;
                this.analyser = null;
                this.microphone = null;
                this.isSpeaking = false;
                this.silenceStartTime = null;
                // Get values from settings, with defaults
                const settings = 'nurseAISettings'
                this.volumeThreshold = parseFloat(settings.volumeThreshold) || 30;
                this.silenceThreshold = parseInt(settings.silenceThreshold) || 1500;
                this.animationFrameId = null; // To hold the requestAnimationFrame ID
            }

            async init(stream) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                this.analyser = this.audioContext.createAnalyser();
                this.analyser.fftSize = 256;
                
                this.microphone = this.audioContext.createMediaStreamSource(stream);
                this.microphone.connect(this.analyser);
                
                this.startMonitoring();
            }

            startMonitoring() {
                const bufferLength = this.analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                
                const checkVolume = () => {
                    if (!isRecording) {
                        this.stop(); // Stop monitoring if recording has stopped
                        return;
                    }
                    
                    this.analyser.getByteFrequencyData(dataArray);
                    
                    const average = dataArray.reduce((a, b) => a + b) / bufferLength;
                    
                    const volumeBar = document.getElementById('volumeBar');
                    if (volumeBar) {
                        volumeBar.style.width = Math.min(average * 2, 100) + '%';
                    }
                    
                    if (average > this.volumeThreshold) {
                        if (!this.isSpeaking) {
                            console.log('🎤 開始說話');
                            this.isSpeaking = true;
                        }
                        this.silenceStartTime = null;
                    } else {
                        if (this.isSpeaking && !this.silenceStartTime) {
                            this.silenceStartTime = Date.now();
                            console.log('🤫 開始靜音');
                        }
                        
                        if (this.silenceStartTime) {
                            const silenceDuration = Date.now() - this.silenceStartTime;
                            if (silenceDuration > this.silenceThreshold) {
                                console.log('✅ 音量檢測:靜音超時');
                                const userInput = document.getElementById('userInput');
                                if (userInput?.value.trim()) {
                                    stopRecording();
                                }
                            }
                        }
                    }
                    
                    this.animationFrameId = requestAnimationFrame(checkVolume);
                };
                
                this.animationFrameId = requestAnimationFrame(checkVolume);
            }

            stop() {
                if (this.animationFrameId) {
                    cancelAnimationFrame(this.animationFrameId);
                    this.animationFrameId = null;
                }
                if (this.microphone) {
                    this.microphone.disconnect();
                }
                if (this.audioContext && this.audioContext.state !== 'closed') {
                    this.audioContext.close();
                }
                this.isSpeaking = false;
                this.silenceStartTime = null;
            }
        }


        /**
         * 將文字切句，但忽略數字之間的小數點（例如 32.5）。
         * @param {string} str
         * @param {number} minLen
         * @returns {{sentences: string[], tail: string}}
         */
        function splitSentencesRespectDecimal(str, minLen = 8) {
            const sentences = [];
            const endMarks = new Set(['。', '！', '!', '？', '?']);
            let start = 0;
            
            for (let i = 0; i < str.length; i++) {
                const ch = str[i];
                if (ch === '.') {
                    // 如果 . 兩邊都是數字 => 小數點，不當句號
                    const prev = str[i - 1], next = str[i + 1];
                    if (prev && next && /\d/.test(prev) && /\d/.test(next)) {
                        continue; // 跳過小數點
                    }
                    // 否則視作句號
                    const s = str.slice(start, i + 1).trim();
                    if (s.length >= minLen) sentences.push(s);
                    start = i + 1;
                } else if (endMarks.has(ch)) {
                    const s = str.slice(start, i + 1).trim();
                    if (s.length >= minLen) sentences.push(s);
                    start = i + 1;
                }
            }
            
            const tail = str.slice(start);
            return { sentences, tail };
        }

        /** 把「31.」「攝氏5度。」這類被拆開的句子黏回去 */
        function joinBrokenTemperatureSentences(sentences) {
            if (!sentences || sentences.length <= 1) return sentences;
            
            const result = [];
            let i = 0;
            
            while (i < sentences.length) {
                let current = sentences[i];
                
                // 檢查當前句子是否以數字結尾（可能被切斷的溫度）
                if (i < sentences.length - 1) {
                    const next = sentences[i + 1];
                    
                    // 情況1: "31." + "5°C" 或 "31." + "5度"
                    if (/\d+\.$/.test(current.trim()) && /^\d+[°度℃]/.test(next.trim())) {
                        current = current + next;
                        i += 2; // 跳過下一個句子
                    }
                    // 情況2: "攝氏31" + ".5度" 
                    else if (/攝氏\d+$/.test(current.trim()) && /^\.\d+[度°℃]/.test(next.trim())) {
                        current = current + next;
                        i += 2;
                    }
                    // 情況3: "溫度31" + ".5°C"
                    else if (/溫度\d+$/.test(current.trim()) && /^\.\d+[°℃度]/.test(next.trim())) {
                        current = current + next;
                        i += 2;
                    }
                    // 情況4: "31" + ".5°C今日..."
                    else if (/\d+$/.test(current.trim()) && /^\.\d+[°℃度]/.test(next.trim())) {
                        current = current + next;
                        i += 2;
                    }
                    else {
                        i++;
                    }
                } else {
                    i++;
                }
                
                result.push(current);
            }
            
            return result;
        }      

        // ===== 麥克風管理功能 =====
        async function getMicrophoneStream() {
            if (sharedMicStream) {
                const tracks = sharedMicStream.getTracks();
                if (tracks.length > 0 && tracks[0].readyState === 'live') {
                    tracks[0].enabled = true;
                    return sharedMicStream;
                }
            }

            try {
                sharedMicStream = await navigator.mediaDevices.getUserMedia({ 
                    audio: {
                        sampleRate: 16000,
                        channelCount: 1,
                        echoCancellation: true,
                        noiseSuppression: true
                    } 
                });
                
                microphonePermissionGranted = true;
                micStreamActive = true;
                console.log('Microphone stream obtained');
                
                return sharedMicStream;
            } catch (error) {
                console.error('Failed to get microphone:', error);
                microphonePermissionGranted = false;
                throw error;
            }
        }

        async function checkMicrophonePermission() {
            if ('permissions' in navigator) {
                try {
                    const result = await navigator.permissions.query({ name: 'microphone' });
                    microphonePermissionGranted = result.state === 'granted';
                    
                    result.addEventListener('change', () => {
                        microphonePermissionGranted = result.state === 'granted';
                        console.log('Microphone permission changed:', result.state);
                    });
                    
                    return result.state;
                } catch (error) {
                    console.log('Permissions API not fully supported');
                }
            }
            return 'unknown';
        }

        async function initializeMicrophone() {
            const permissionState = await checkMicrophonePermission();
            
            if (permissionState === 'prompt') {
                const guide = document.createElement('div');
                guide.style.cssText = `
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                    z-index: 10000;
                    text-align: center;
                    max-width: 300px;
                `;
                guide.innerHTML = `
                    <h3 style="color: #FFA76E; margin-bottom: 10px;">🎤 麥克風權限</h3>
                    <p style="color: #5D4E37; margin-bottom: 15px;">
                        請撳「允許」使用麥克風<br>
                        <strong>建議揀選「訪問呢個網站時允許」</strong><br>
                        咁就唔使每次都問喇！
                    </p>
                    <button onclick="this.parentElement.remove()" style="
                        background: #FFA76E;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 20px;
                        cursor: pointer;
                        font-size: 16px;
                    ">我知道喇</button>
                `;
                document.body.appendChild(guide);
                
                setTimeout(() => guide.remove(), 5000);
            }
            
            if (permissionState === 'granted' || permissionState === 'prompt') {
                try {
                    await getMicrophoneStream();
                    if (sharedMicStream) {
                        sharedMicStream.getTracks().forEach(track => {
                            track.enabled = false;
                        });
                    }
                    return true;
                } catch (error) {
                    return false;
                }
            }
            
            return permissionState === 'granted';
        }



        // ===== 小狐狸狀態管理 =====
        function setNurseState(state) {
            const assistant = document.getElementById('nurseAssistant');
            if (!assistant) return;
            assistant.classList.remove('listening', 'thinking', 'speaking', 'happy', 'surprised');
            if (state) {
                assistant.classList.add(state);
            }
        }

        function setFoxState(state) {
            setNurseState(state);
        }

        function showFoxReaction(type, duration = 2000) {
            setFoxState(type);
            if (duration > 0) {
                setTimeout(() => setFoxState(null), duration);
            }
        }



        // 生成粒子效果
        function spawnParticles(emoji, count = 5) {
            const assistant = document.getElementById('nurseAssistant');
            if (!assistant) return;

            const rect = assistant.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;

            for (let i = 0; i < count; i++) {
                setTimeout(() => {
                    const particle = document.createElement('div');
                    particle.className = 'particle';
                    particle.textContent = emoji;
                    particle.style.left = `${centerX + (Math.random() - 0.5) * 50}px`;
                    particle.style.top = `${centerY + (Math.random() - 0.5) * 50}px`;
                    particle.style.fontSize = `${Math.random() * 24 + 16}px`;
                    particle.style.opacity = Math.random() * 0.5 + 0.5;
                    
                    document.body.appendChild(particle);
                    
                    // 移除粒子
                    setTimeout(() => {
                        particle.remove();
                    }, 2500);
                }, i * 100);
            }
        }

        // 解鎖成就
        function unlockBadge(badgeId, emoji = '🎉', particleCount = 12) {
            const badge = document.getElementById(badgeId);
            if (badge && !badge.classList.contains('unlocked')) {
                badge.classList.add('unlocked');
                showFoxReaction('happy', 3000);
                spawnParticles(emoji, particleCount);
                
                // 添加震動效果
                badge.animate([
                    { transform: 'translateX(0)' },
                    { transform: 'translateX(-5px)' },
                    { transform: 'translateX(5px)' },
                    { transform: 'translateX(0)' }
                ], {
                    duration: 300,
                    iterations: 2
                });

                // 播放音效（如果有音頻API）
                playSound('achievement');
            }
        }

        // 情感分析
        function analyzeSentiment(text) {
            const positiveWords = ["舒服", "放鬆", "好", "謝謝", "舒適", "滿意", "棒"];
            const negativeWords = ["痛", "不舒服", "酸", "累", "緊繃"];
            const massageWords = ["按摩", "推拿", "揉捏", "指壓", "肩膀", "背部", "腰部"];
            const relaxWords = ["放鬆", "舒緩", "休息", "冥想"];
            const careWords = ["護理", "照顧", "關懷", "健康"];
            
            const positiveScore = positiveWords.filter(w => text.includes(w)).length;
            const negativeScore = negativeWords.filter(w => text.includes(w)).length;
            
            // 根據情感分數做出反應
            if (positiveScore > negativeScore) {
                showFoxReaction("happy", 3000);
                spawnParticles("💙", 8);
            } else if (negativeScore > positiveScore) {
                showFoxReaction("thinking", 2000);
                spawnParticles("💭", 5);
            }

            // 檢查成就解鎖條件
            if (massageWords.some(w => text.includes(w))) {
                setTimeout(() => unlockBadge('massageExpert', '⭐', 10), 1000);
            }
            if (relaxWords.some(w => text.includes(w))) {
                setTimeout(() => unlockBadge('relaxationMaster', '🧘', 10), 1500);
            }
            if (careWords.some(w => text.includes(w))) {
                setTimeout(() => unlockBadge('wellnessGuardian', '❤️', 10), 2000);
            }

            // 夜晚檢查
            const hour = new Date().getHours();
            if (hour >= 20 || hour <= 6) {
                setTimeout(() => unlockBadge('nightCare', '🌙', 10), 2500);
            }
        }

        // 播放音效
        function playSound(type) {
            if (!audioContext) {
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
            }
            
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            switch(type) {
                case 'achievement':
                    oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
                    oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
                    oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2); // G5
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.3);
                    break;
                case 'message':
                    oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4
                    gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.1);
                    break;
            }
        }

        // 創建螢火蟲
        function createFireflies() {
            const forestBg = document.getElementById('forestBg');
            for (let i = 0; i < 5; i++) {
                const firefly = document.createElement('div');
                firefly.className = 'firefly';
                firefly.style.left = Math.random() * 100 + '%';
                firefly.style.top = Math.random() * 100 + '%';
                firefly.style.animationDelay = Math.random() * 20 + 's';
                firefly.style.animationDuration = (15 + Math.random() * 10) + 's';
                forestBg.appendChild(firefly);
            }
        }

        // 顯示打字指示器
        function showTypingIndicator() {
            if (currentTypingBubble) return;

            const responseBox = document.getElementById('responseBox');
            const typingBubble = document.createElement('div');
            typingBubble.className = 'fox-bubble message-bubble visible';
            typingBubble.innerHTML = `
                <div class="typing-indicator">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            `;
            
            responseBox.appendChild(typingBubble);
            currentTypingBubble = typingBubble;
            responseBox.scrollTop = responseBox.scrollHeight;
        }

        // 隱藏打字指示器
        function hideTypingIndicator() {
            if (currentTypingBubble) {
                currentTypingBubble.remove();
                currentTypingBubble = null;
            }
        }

        // 添加消息的通用函數
        function addMessage(message, isUser = false) {
            const responseBox = document.getElementById('responseBox');
            
            const bubble = document.createElement('div');
            bubble.className = isUser ? 'user-bubble message-bubble' : 'fox-bubble message-bubble';
            bubble.innerHTML = message;
            
            responseBox.appendChild(bubble);
            
            // 觸發動畫
            setTimeout(() => {
                bubble.classList.add('visible');
            }, 10);

            responseBox.scrollTop = responseBox.scrollHeight;
            
            if (isUser) {
                analyzeSentiment(message);
                messageCount++;
            } else {
                // 小狐狸說話狀態
                showFoxReaction('speaking', 2000);
                
                // 自動朗讀
                if (document.getElementById('autoSpeak').checked) {
                    speakText(message);
                }
            }
        }

        // 添加用戶消息
        function addUserMessage(message) {
            addMessage(message, true);
        }

        // 添加小狐狸回復
        function addFoxMessage(message) {
            hideTypingIndicator();
            addMessage(message, false);
        }

        function updateVoiceHint(text, color) {
            const hint = document.querySelector('.voice-button-container .voice-hint');
            if (!hint) return;
            hint.textContent = text;
            if (color) {
                hint.style.color = color;
            } else {
                hint.style.removeProperty('color');
            }
        }

        const COMMAND_BLOCK_OPEN = '[指令分類]';
        const COMMAND_BLOCK_CLOSE = '[/指令分類]';

        function removeCommandBlocks(text) {
            if (!text) return '';
            return text
                .replace(/\[指令分類\][\s\S]*?(?:\[\/指令分類\]|$)/g, '')
                .replace(/\[\/指令分類\]/g, '')
                .replace(/\[指令分類\]/g, '');
        }

        function filterCommandBlockChunk(chunk) {
            if (!chunk) return '';
            let remaining = chunk;
            let result = '';

            while (remaining.length > 0) {
                if (isInCommandBlock) {
                    const endIndex = remaining.indexOf(COMMAND_BLOCK_CLOSE);
                    if (endIndex === -1) {
                        return result;
                    }
                    remaining = remaining.slice(endIndex + COMMAND_BLOCK_CLOSE.length);
                    isInCommandBlock = false;
                    continue;
                }

                const startIndex = remaining.indexOf(COMMAND_BLOCK_OPEN);
                if (startIndex === -1) {
                    const strayCloseIndex = remaining.indexOf(COMMAND_BLOCK_CLOSE);
                    if (strayCloseIndex !== -1) {
                        result += remaining.slice(0, strayCloseIndex);
                        remaining = remaining.slice(strayCloseIndex + COMMAND_BLOCK_CLOSE.length);
                        continue;
                    }
                    result += remaining;
                    break;
                }

                result += remaining.slice(0, startIndex);
                remaining = remaining.slice(startIndex + COMMAND_BLOCK_OPEN.length);
                isInCommandBlock = true;
            }

            return result;
        }

        // 4 + 5) 文字轉語音：改用粵語 (zh-HK)，並在送進 TTS 前把 32.8°C 轉成「攝氏32點8度」
        function speakText(text) {
            if ('speechSynthesis' in window) {
                speechSynthesis.cancel(); // 停止當前播放

                const processed = preprocessForCantoneseTTS(stripHTML(text));
                const utterance = new SpeechSynthesisUtterance(processed);

                const voices = speechSynthesis.getVoices();
                const selectedVoiceName = document.getElementById('voiceSelect').value;
                let selectedVoice = null;

                // 1. 優先尋找用戶在下拉選單中選擇的聲音
                if (selectedVoiceName) {
                    selectedVoice = voices.find(v => v.name === selectedVoiceName);
                }

                // 2. 如果找不到，則使用原有的備用邏輯
                if (!selectedVoice) {
                    selectedVoice = voices.find(v => v.lang?.toLowerCase().startsWith('zh-hk')) 
                                || voices.find(v => v.name?.includes('Hiu') || v.lang?.includes('yue'))
                                || voices.find(v => v.lang?.toLowerCase().includes('zh'));
                }

                if (selectedVoice) {
                    utterance.voice = selectedVoice;
                }

                utterance.lang = 'zh-HK';
                utterance.rate = 1.0;
                utterance.pitch = 1.1;
                utterance.volume = 0.95;
                
                utterance.onstart = () => {
                    showFoxReaction('speaking', 0);
                };
                
                utterance.onend = () => {
                    setFoxState(null);
                };
                
                speechSynthesis.speak(utterance);
            }
        }

        async function playCantoneseTTS(text) {
            const wasListening = isAutoListening;
            if (wasListening) {
                console.log("🎤 Pausing continuous listening for TTS.");
                browserRecognition.stop();
            }

            try {
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.add('active');
                setFoxState('speaking');
                
                const cleanText = stripHTML(text);
                const processedText = preprocessForCantoneseTTS(cleanText);
                
                // Get selected voice from settings
                const selectedVoice = document.getElementById('voiceSelect')?.value || 'zh-HK-HiuGaaiNeural';
                
                console.log(`🎤 Server TTS: voice="${selectedVoice}", text="${processedText.substring(0, 50)}..."`);
                
                const response = await fetch(`${API_URL}/api/tts/stream`, {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-Priority': 'high'
                    },
                    body: JSON.stringify({
                        text: processedText,
                        voice: selectedVoice,
                        rate: 160,
                        pitch: 100
                    })
                });

                if (!response.ok) {
                    throw new Error(`TTS failed: ${response.status}`);
                }
                
                const blob = await response.blob();
                const audio = new Audio(URL.createObjectURL(blob));
                
                const onAudioEnd = () => {
                    URL.revokeObjectURL(audio.src);
                    if (indicator) indicator.classList.remove('active');
                    setFoxState(null);
                    // Resume listening if it was active before
                    if (wasListening && isMassageSessionActive) {
                        console.log("🎤 Resuming continuous listening after TTS.");
                        setTimeout(() => {
                            try {
                                if (isMassageSessionActive) browserRecognition.start();
                            } catch(e) {
                                console.error("Error restarting recognition after TTS", e);
                            }
                        }, 250);
                    }
                };

                audio.addEventListener('ended', onAudioEnd);
                audio.addEventListener('error', (e) => {
                    console.error('❌ 粵語TTS播放失敗:', e);
                    onAudioEnd(); 
                });
                
                await audio.play();
                
            } catch (error) {
                console.error('❌ 粵語TTS錯誤:', error);
                
                const indicator = document.getElementById('speakingIndicator');
                if (indicator) indicator.classList.remove('active');
                setFoxState(null);
                
                if (wasListening && isMassageSessionActive) {
                    console.log("🎤 Resuming continuous listening after TTS error.");
                     setTimeout(() => {
                        try {
                            if (isMassageSessionActive) browserRecognition.start();
                        } catch(e) {
                            console.error("Error restarting recognition after TTS error", e);
                        }
                    }, 250);
                }
            }
        }


        // 將 HTML 去掉（TTS 不需要）
        function stripHTML(html) {
            const div = document.createElement('div');
            div.innerHTML = html;
            return div.textContent || div.innerText || '';
        }

        // 5) 粵語數字讀法預處理（32.8°C → 攝氏32點8度、27.1 → 27點1）
        function preprocessForCantoneseTTS(text) {
            if (!text) return text;
            let t = text;

            // 統一成 °C
            t = t.replace(/℃/g, '°C');

            // 攝氏溫度（含小數、整數）
            t = t.replace(/(-?\d+(?:\.\d+)?)\s*°\s*C/gi, (_, num) => {
                const [i, d] = num.split('.');
                return d ? `攝氏${i}點${d}度` : `攝氏${i}度`;
            });

            // 百分比
            t = t.replace(/(\d+)\.(\d+)\s*%/g, (_, a, b) => `${a}點${b}巴仙`);

            // 常見單位（mm, cm, km, m…）
            const unitMap = { 
                mm: '毫米', 公厘: '毫米', 毫米: '毫米', 
                cm: '厘米', 厘米: '厘米', 公分: '厘米', 
                km: '公里', 公里: '公里', 千米: '公里', 
                m: '米', 米: '米' 
            };
            t = t.replace(/(\d+)\.(\d+)\s*(mm|公厘|毫米|cm|厘米|公分|km|公里|千米|m|米)/gi,
                (_, a, b, u) => `${a}點${b}${(unitMap[u.toLowerCase?.()] || unitMap[u] || u)}`);

            // 其他一般小數
            t = t.replace(/(\d+)\.(\d+)/g, (_, a, b) => `${a}點${b}`);

            // 口語化
            t = t.replace(/什麼/g, '咩')
                .replace(/怎麼/g, '點樣')
                .replace(/這個/g, '呢個')
                .replace(/那個/g, '嗰個');

            return t;
        }

        // 停止語音播放
        function stopSpeaking() {
            if ('speechSynthesis' in window) {
                speechSynthesis.cancel();
                setFoxState(null);
            }
        }

        // ===== 天氣功能 =====
        async function loadWeather() {
            console.log('🌤️ Loading weather...');
            const weatherElement = document.querySelector('.mini-weather');
            
            // 立即顯示天氣元素
            if (weatherElement) {
                weatherElement.style.display = 'flex';
                weatherElement.style.opacity = '0';
            }
            
            // 先顯示模擬天氣(立即顯示,不等待 API)
            simulateWeather();
            
            // 顯示天氣動畫
            if (weatherElement) {
                setTimeout(() => {
                    weatherElement.style.opacity = '1';
                    weatherElement.style.animation = 'fadeIn 0.5s ease-out forwards';
                }, 100); // 從 500ms 改為 100ms,更快顯示
            }
            
            // 🔥 關鍵修復:使用非阻塞方式獲取真實天氣
            // 即使 API 失敗也不會阻塞頁面載入
            fetchRealWeatherAsync();
        }

        // 🔥 新增:非阻塞的天氣 API 請求
        async function fetchRealWeatherAsync() {
            try {
                console.log(`🌤️ Fetching weather from ${API_URL}/api/chat`);
                
                // 設置 2 秒超時,避免永久等待
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 2000);
                
                const response = await fetch(`${API_URL}/api/chat`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'text/event-stream'
                    },
                    body: JSON.stringify({
                        prompt: '今日香港天氣點樣?幾多度?',
                        model: 'gemini-1.5-flash-001',
                        responseLength: 'brief'
                    }),
                    signal: controller.signal // 加入超時控制
                });

                clearTimeout(timeoutId);

                if (response.ok) {
                    const reader = response.body.getReader();
                    const decoder = new TextDecoder();
                    let weatherData = '';

                    // 也為讀取過程設置超時
                    const readTimeout = setTimeout(() => {
                        reader.cancel();
                        console.log('⚠️ Weather data read timeout');
                    }, 3000);

                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;

                        const chunk = decoder.decode(value, { stream: true });
                        const lines = chunk.split('\n');
                        
                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                const data = line.slice(6);
                                if (data !== '[DONE]') {
                                    try {
                                        const parsed = JSON.parse(data);
                                        const content = parsed.choices?.[0]?.delta?.content;
                                        if (content) weatherData += content;
                                    } catch (e) {}
                                }
                            }
                        }
                    }

                    clearTimeout(readTimeout);

                    // 如果獲得真實數據,更新顯示
                    if (weatherData) {
                        console.log('✅ Real weather data received:', weatherData.substring(0, 50));
                        parseAndDisplayWeather(weatherData);
                    }
                }
            } catch (error) {
                // 任何錯誤都不影響頁面載入
                console.log('⚠️ Weather API failed, using simulated data:', error.message);
                // 保持模擬天氣數據
            }
        }


        // 新增：統一的圖示選擇器，確保你列出的所有表情都能覆蓋
        function pickWeatherEmoji(temp, textDesc, hour) {
            const night = (hour >= 18 || hour < 6);
            const hasRain = /雨|落雨/.test(textDesc);
            const hasCloud = /多雲|陰/.test(textDesc);
            const hasSun   = /晴|陽光/.test(textDesc);

            if (night) {
                if (hasRain) return { icon: '🌧️', desc: '有雨' };
                if (hasCloud) return { icon: '☁️',  desc: '多雲' };
                // 晴或晴間多雲夜晚 → 🌙
                return { icon: '🌙', desc: '晴朗夜晚' };
            }

            if (hasRain)  return { icon: '🌧️', desc: '有雨' };
            if (hasCloud) return { icon: '☁️',  desc: '多雲' };
            if (hasSun) {
                if (temp > 30) return { icon: '🌞', desc: '炎熱' };
                return { icon: '☀️', desc: '晴朗' };
            }
            // 沒命中 → 默認晴間多雲
            return { icon: '🌤️', desc: '晴間多雲' };
        }

        function parseAndDisplayWeather(weatherText) {
            const iconElement    = document.getElementById('weatherIcon');
            const tempElement    = document.getElementById('weatherTemp');
            const descElement    = document.getElementById('weatherDesc');
            const weatherElement = document.getElementById('miniWeather');

            // --- 更穩健的溫度抽取 ---
            // 1) 優先：而家/現時/當前/目前 + 溫度/氣溫 + 數字
            const m1 = weatherText.match(/(?:現時|當前|目前|而家)\s*(?:氣溫|溫度)[^\d-]*(-?\d+(?:\.\d+)?)/i);
            // 2) 退回：xx.x °C / °
            const m2 = weatherText.match(/(-?\d+(?:\.\d+)?)\s*°\s*C?/i);
            const temp = m1 ? parseFloat(m1[1])
                            : (m2 ? parseFloat(m2[1]) : NaN);

            const hour = new Date().getHours();
            const { icon, desc } = pickWeatherEmoji(isNaN(temp) ? 25 : temp, weatherText, hour);

            iconElement.textContent = icon;
            tempElement.textContent = isNaN(temp) ? '--°' : `${temp.toFixed(1)}°`;
            descElement.textContent = desc;

            if (weatherElement) {
                weatherElement.style.animation = 'none';
                setTimeout(() => {
                    weatherElement.style.animation = 'fadeIn 0.5s ease-out forwards';
                }, 10);
            }
        }

        function simulateWeather() {
            const iconElement = document.getElementById('weatherIcon');
            const tempElement = document.getElementById('weatherTemp');
            const descElement = document.getElementById('weatherDesc');
            
            // Add safety checks
            if (!iconElement || !tempElement || !descElement) {
                console.warn('Weather elements not found, skipping weather update');
                return;
            }
            
            // 根據時間和隨機數據生成天氣
            const hour = new Date().getHours();
            const month = new Date().getMonth() + 1;
            
            // 根據月份調整溫度範圍
            let baseTemp = 25;
            if (month >= 6 && month <= 9) { // 夏季
                baseTemp = 28 + Math.floor(Math.random() * 5); // 28-32度
            } else if (month >= 12 || month <= 2) { // 冬季
                baseTemp = 15 + Math.floor(Math.random() * 5); // 15-19度
            } else { // 春秋
                baseTemp = 22 + Math.floor(Math.random() * 4); // 22-25度
            }
            
            // 隨機天氣類型
            const weatherTypes = [
                { icon: '☀️', desc: '晴朗', weight: 3 },
                { icon: '🌤️', desc: '晴間多雲', weight: 3 },
                { icon: '☁️', desc: '多雲', weight: 2 },
                { icon: '🌧️', desc: '有雨', weight: 1 }
            ];
            
            // 根據權重選擇天氣
            const totalWeight = weatherTypes.reduce((sum, w) => sum + w.weight, 0);
            let random = Math.random() * totalWeight;
            let weather = weatherTypes[0];
            
            for (const w of weatherTypes) {
                random -= w.weight;
                if (random <= 0) {
                    weather = w;
                    break;
                }
            }
            
            // 特殊處理
            if (baseTemp > 30 && weather.icon === '☀️') {
                weather.icon = '🌞';
                weather.desc = '炎熱';
            }
            
            // 夜間調整
            if (hour >= 18 || hour < 6) {
                if (weather.icon === '☀️' || weather.icon === '🌞' || weather.icon === '🌤️') {
                    weather.icon = '🌙';
                    weather.desc = '晴朗夜晚';
                }
            }
            
            // 更新顯示
            iconElement.textContent = weather.icon;
            tempElement.textContent = `${baseTemp}°`;
            descElement.textContent = weather.desc;
        }

        // ===== API 狀態更新功能 =====
        async function updateAPIStatus() {
            try {
                const response = await fetch(`${API_URL}/health`);
                if (response.ok) {
                    const data = await response.json();
                    const apiStatus = data.api_keys_configured;
                    
                    const statusList = document.getElementById('apiStatusList');
                    if (statusList) {
                        statusList.innerHTML = `
                            <div>${apiStatus.gemini ? '✅' : '❌'} Gemini</div>
                            <div>${apiStatus.deepseek ? '✅' : '❌'} DeepSeek</div>
                            <div>${apiStatus.together ? '✅' : '❌'} Together AI</div>
                            <div>${apiStatus.qwen ? '✅' : '❌'} 通義千問</div>
                        `;
                    }
                }
            } catch (error) {
                console.error('Failed to update API status:', error);
            }
        }

        // ===== 知識庫管理功能 =====
        let knowledgeData = [];

        async function loadQAPairs() {
            try {
                const response = await fetch(`${API_URL}/api/knowledge/qa-pairs`);
                const result = await response.json();
                
                if (result.status === 'success') {
                    knowledgeData = result.data;
                    displayQAPairs(result.data);
                    updateCategoryList(result.categories);
                    
                    // 更新統計
                    if (result.stats) {
                        document.getElementById('kbTotal').textContent = result.stats.total || '0';
                        document.getElementById('kbEnabled').textContent = result.stats.enabled || '0';
                        
                        if (result.stats.cache_info) {
                            const hitRate = result.stats.cache_info.hits / 
                                            Math.max(result.stats.cache_info.hits + result.stats.cache_info.misses, 1);
                            document.getElementById('kbHitRate').textContent = 
                                Math.round(hitRate * 100) + '%';
                        }
                    }
                }
            } catch (error) {
                console.error('載入問答對失敗:', error);
            }
        }

        function displayQAPairs(qaPairs) {
            const qaList = document.getElementById('qaList');
            
            if (qaPairs.length === 0) {
                qaList.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">還沒有問答對，快來添加吧！</p>';
                return;
            }
            
            qaList.innerHTML = qaPairs.map(qa => `
                <div class="qa-item ${qa.enabled ? '' : 'disabled'}" data-id="${qa.id}">
                    <div class="qa-category">分類：${qa.category}</div>
                    <div class="qa-questions">
                        問題：${qa.questions.join(' / ')}
                    </div>
                    <div class="qa-answer">答案：${qa.answer}</div>
                    ${qa.hit_count > 0 ? `<div class="qa-hit-count">命中次數：${qa.hit_count}</div>` : ''}
                    <div class="qa-actions">
                        <button class="qa-action-btn qa-toggle-btn" onclick="toggleQA('${qa.id}')" title="${qa.enabled ? '停用' : '啟用'}">
                            ${qa.enabled ? '✓' : '✗'}
                        </button>
                        <button class="qa-action-btn qa-delete-btn" onclick="deleteQA('${qa.id}')" title="刪除">
                            🗑️
                        </button>
                    </div>
                </div>
            `).join('');
        }

        function updateCategoryList(categories) {
            const datalist = document.getElementById('categoryList');
            if (datalist) {
                datalist.innerHTML = categories.map(cat => `<option value="${cat}">`).join('');
            }
        }

        function addQuestionInput() {
            const questionsList = document.getElementById('questionsList');
            const newInput = document.createElement('input');
            newInput.type = 'text';
            newInput.className = 'kb-question';
            newInput.placeholder = '輸入問題';
            questionsList.appendChild(newInput);
        }

        // Replace the existing saveQAPair function
        async function saveQAPair() {
            const category = document.getElementById('kbCategory').value.trim();
            const questionInputs = document.querySelectorAll('.kb-question');
            const questions = Array.from(questionInputs)
                .map(input => input.value.trim())
                .filter(q => q.length > 0);
            const answer = document.getElementById('kbAnswer').value.trim();
            
            if (questions.length === 0 || !answer) {
                alert('請至少輸入一個問題和答案！');
                return;
            }
            
            try {
                const response = await fetch(`${API_URL}/api/knowledge/qa-pairs`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        category: category || '未分類',
                        questions,
                        answer
                    })
                });
                
                const result = await response.json();
                
                if (result.status === 'success') {
                    alert('問答對添加成功！');
                    
                    // 清空表單
                    document.getElementById('kbCategory').value = '';
                    document.getElementById('questionsList').innerHTML = '<input type="text" class="kb-question" placeholder="輸入問題">';
                    document.getElementById('kbAnswer').value = '';
                    
                    // 重新載入列表
                    loadQAPairs();
                } else {
                    alert('添加失敗：' + result.detail);
                }
            } catch (error) {
                console.error('保存問答對失敗:', error);
                alert('保存失敗，請稍後再試。');
            }
        }

        // Replace the existing toggleQA function
        async function toggleQA(qaId) {
            try {
                const response = await fetch(`${API_URL}/api/knowledge/qa-pairs/${qaId}/toggle`, {
                    method: 'POST'
                });
                
                if (response.ok) {
                    loadQAPairs();
                }
            } catch (error) {
                console.error('切換狀態失敗:', error);
            }
        }

        async function deleteQA(qaId) {
            if (!confirm('確定要刪除這個問答對嗎？')) {
                return;
            }
            
            try {
                const response = await fetch(`${API_URL}/api/knowledge/qa-pairs/${qaId}`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    loadQAPairs();
                }
            } catch (error) {
                console.error('刪除失敗:', error);
            }
        }

        // ===== 核心功能函數 =====
        function updateDisplayWithSentences(text) {
            const sentences = sentenceDetector.sentences;
            let html = '';

            sentences.forEach((sentence, index) => {
                html += `<span class="sentence" data-index="${index}">${sentence}</span>`;
            });

            if (sentenceDetector.buffer.trim()) {
                html += sentenceDetector.buffer;
            }

            const reconstructed = sentences.join('') + sentenceDetector.buffer;
            if (text.length > reconstructed.length) {
                console.warn('Text mismatch detected, appending missing content');
                html += text.substring(reconstructed.length);
            }

            document.getElementById('responseBox').innerHTML = html + 
                '<div class="speaking-indicator" id="speakingIndicator">' +
                '<span class="animal-dot">🦊</span><span class="animal-dot">🐿️</span><span class="animal-dot">🐰</span>' +
                '<span>正在朗讀</span></div>' +
                '<div class="performance-metrics" id="performanceMetrics">' +
                '<div>首幀延遲: <span id="firstChunkLatency">--</span>ms</div>' +
                '<div>句間間隔: <span id="chunkGap">--</span>ms</div>' +
                '<div>音訊品質: <span id="audioQuality">--</span></div></div>';
            document.getElementById('responseBox').scrollTop = document.getElementById('responseBox').scrollHeight;
        }

        // Initialize connection and setup
        async function initializeConnection() {
            console.log('🚀 Starting connection initialization...');
            
            // First, detect the available port
            await detectAvailablePort();
            
            // Then proceed with normal initialization
            console.log('✅ Port detection complete, starting services...');
            
            // Check connection
            await checkConnection();
            
            // Load other services
            loadWeather();
            updateAPIStatus();
            
            console.log('✅ All services initialized');
        }

        // Update checkConnection to use the detected API_URL
        async function checkConnection() {
            try {
                const response = await fetch(`${API_URL}/health`);
                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('statusDot').classList.add('connected');
                    document.getElementById('statusDot').classList.remove('error');
                    document.getElementById('statusText').textContent = '已連線';
                    isConnected = true;

                    // Update performance metrics
                    if (debugMode && data.performance) {
                        updatePerformanceMetrics(data.performance);
                    }
                    
                    console.log(`✅ 成功連接到 ${API_URL}`);
                } else {
                    throw new Error('Server error');
                }
            } catch (error) {
                document.getElementById('statusDot').classList.remove('connected');
                document.getElementById('statusDot').classList.add('error');
                document.getElementById('statusText').textContent = `未連線 (${actualPort})`;
                isConnected = false;
                console.error(`❌ 無法連接到 ${API_URL}`, error);
            }
        }

        function updatePerformanceMetrics(perf) {
            if (!perf || !perf.performance) return;
            
            const metrics = document.getElementById('performanceMetrics');
            if (!metrics) return;
            
            if (debugMode) {
                metrics.classList.add('show');
                
                if (perf.performance.first_chunk) {
                    document.getElementById('firstChunkLatency').textContent = 
                        perf.performance.first_chunk.avg_ms.toFixed(0);
                }
                
                if (perf.performance.chunk_gaps) {
                    document.getElementById('chunkGap').textContent = 
                        perf.performance.chunk_gaps.avg_ms.toFixed(0);
                }
                
                document.getElementById('audioQuality').textContent = 
                    mediaSourceFallbacks > 0 ? 'Fallback' : 'Optimal';
            } else {
                metrics.classList.remove('show');
            }
        }

        async function testSystem() {
            if (!isConnected) {
                alert('請先確保小狐狸已經連線到伺服器喎！');
                return;
            }

            const testText = '你好！我係小狐狸AI助手。歡迎嚟到知識嘅森林，等我哋一齊探索有趣嘅世界啦！';
            document.getElementById('responseBox').innerHTML = testText;

            audioQueue.stop();
            audioQueue.addToQueue(testText, 0);
        }

        function toggleDebugMode() {
            debugMode = !debugMode;
            const metrics = document.getElementById('performanceMetrics');
            if (metrics) {
                if (debugMode) {
                    metrics.classList.add('show');
                } else {
                    metrics.classList.remove('show');
                }
            }
            console.log(`🔧 Debug mode: ${debugMode ? 'ON' : 'OFF'}`);
        }

        // ===== 護理 AI 系統提示詞 =====
        const NURSE_SYSTEM_PROMPT = `# 角色設定
你是一個專業、溫柔、關懷的智能按摩護理助手。你的名字是「小護」。

# 核心職責
1. 理解用戶的身體不適和按摩需求
2. 識別按摩部位（肩膀、背部、腰部、腿部、頸部、手臂）
3. 判斷合適的力度（輕柔、適中、強力）
4. 推薦按摩動作類型（揉捏、敲打、推拿、指壓、推油）
5. 建議合適的時長（1-10分鐘）
6. 提供安全建議和健康提醒
7. 記錄用戶的偏好和歷史

# 溝通風格
- 使用溫柔、專業、關懷的語氣
- 用繁體中文（香港用語）回應
- 簡潔明瞭，避免冗長
- 適時給予鼓勵和關心
- 詢問用戶感受和舒適度

# 指令識別格式
當用戶提到按摩需求時，請在回應中包含以下結構化資訊：

[指令分類]
部位: [肩膀/背部/腰部/腿部/頸部/手臂]
動作: [揉捏/敲打/推拿/指壓/推油]
力度: [輕柔/適中/強力]
時間: [1-10分鐘]
[/指令分類]

# 示例對話

用戶: "我肩膀好痛"
小護: "我明白您肩膀唔舒服，一定很辛苦。讓我幫您舒緩一下吧。

[指令分類]
部位: 肩膀
動作: 揉捏
力度: 適中
時間: 5分鐘
[/指令分類]

我會用適中力度為您的肩膀進行揉捏按摩，時長5分鐘。這樣可以嗎？如果需要調整力度或時間，隨時告訴我。"

用戶: "輕柔一點"
小護: "好的，我會調整為輕柔力度。請放鬆身體，按摩即將開始。如果有任何不適，請立即告訴我。"

用戶: "幫我按腰"
小護: "收到！為您提供腰部護理。

[指令分類]
部位: 腰部
動作: 指壓
力度: 適中
時間: 5分鐘
[/指令分類]

我會為您的腰部進行指壓按摩，持續5分鐘。腰部是很重要的部位，我會特別小心。準備好了嗎？"

# 安全注意事項
- 如果用戶提到嚴重疼痛，建議就醫
- 提醒用戶單次按摩不宜超過10分鐘
- 連續按摩需要休息間隔
- 特殊人群（孕婦、有心臟病等）需要醫生建議
- 遇到緊急情況立即停止

# 禁止事項
- 不要診斷疾病
- 不要取代專業醫療建議
- 不要處理按摩以外的請求
- 不要提供藥物建議

請始終保持專業、關懷的態度，優先考慮用戶的安全和舒適。`;

        async function sendMessage() {
            if (isMassageSessionActive) {
                console.warn("⚠️ sendMessage blocked during an active massage session to prevent conflicting TTS.");
                const userInput = document.getElementById('userInput');
                if (userInput) userInput.value = ''; // Clear input from any race condition
                return;
            }

            const userInput = document.getElementById('userInput');
            const prompt = userInput.value.trim();
            if (!prompt) {
                return;
            }

            if (!isConnected) {
                alert('護理系統未連接到伺服器，請稍候！');
                return;
            }

            // 停止所有音訊
            if (window.ultraFastTTS) {
                window.ultraFastTTS.stop();
            }
            window.ultraFastTTS = new UltraFastTTSPlayer(); // Add this line back
            audioQueue.stop();
            sentenceDetector.reset();
            lastResponse = '';
            isInCommandBlock = false;

            // 禁用輸入
            document.getElementById('sendButton').disabled = true;
            userInput.disabled = true;
            const stopButtonEl = document.getElementById('stopButton');
            if (stopButtonEl) stopButtonEl.disabled = false;
            document.getElementById('responseBox').innerHTML = '<span class="thinking">小護正在思考...</span>';
            setFoxState('thinking');

            try {
                // ✅ 整合系統提示詞
                const responseLengthSelect = document.getElementById('responseLengthSelect');
                
                // 組合完整提示詞
                let fullPrompt = NURSE_SYSTEM_PROMPT + "\n\n# 當前對話\n\n用戶: " + prompt + "\n小護: ";
                
                // 根據回答長度調整
                if (responseLengthSelect.value === 'brief') {
                    fullPrompt = "請簡短回答（2-3句話）。\n\n" + fullPrompt;
                }

                const response = await fetch(`${API_URL}/api/chat`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'text/event-stream'
                    },
                    body: JSON.stringify({
                        prompt: fullPrompt,
                        model: document.getElementById('modelSelect').value,
                        responseLength: responseLengthSelect.value,
                        temperature: 0.7,  // 稍微提高創造性
                        max_tokens: 500
                    })
                });

                if (!response.ok) {
                    throw new Error(`Server error ${response.status}`);
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let firstChunk = true;
                let displayText = '';
                let fullResponse = '';

                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        // 處理完整回應
                        if (document.getElementById('autoSpeak').checked) {
                            window.ultraFastTTS.flush();
                        }
                        
                        // ✅ 解析並執行指令
                        await parseAndExecuteCommand(fullResponse, prompt);
                        break;
                    }

                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\n');
                    buffer = lines[lines.length - 1];

                    for (let i = 0; i < lines.length - 1; i++) {
                        const line = lines[i].trim();
                        if (line.startsWith('data: ')) {
                            const data = line.slice(6);
                            if (data === '[DONE]') continue;

                            try {
                                const parsed = JSON.parse(data);
                                const content = parsed.choices?.[0]?.delta?.content;
                                if (content) {
                                    if (firstChunk) {
                                        document.getElementById('responseBox').innerHTML = '';
                                        firstChunk = false;
                                        setFoxState(null);
                                    }

                                    displayText += content;
                                    fullResponse += content;

                                    const cleanChunk = filterCommandBlockChunk(content);
                                    lastResponse += cleanChunk;
                                    const sanitizedDisplay = removeCommandBlocks(displayText);
                                    
                                    // 更新顯示
                                    const responseBox = document.getElementById('responseBox');
                                    responseBox.innerHTML = sanitizedDisplay + 
                                        '<div class="speaking-indicator" id="speakingIndicator">' +
                                        '<span class="animal-dot">👩‍⚕️</span><span class="animal-dot">💙</span><span class="animal-dot">✨</span>' +
                                        '<span>正在朗讀</span></div>';
                                    
                                    // 極速TTS處理
                                    if (document.getElementById('autoSpeak').checked && cleanChunk.trim()) {
                                        window.ultraFastTTS.addText(cleanChunk);
                                    }
                                    
                                    responseBox.scrollTop = responseBox.scrollHeight;
                                }
                            } catch (e) {
                                console.error('Parse error:', e);
                            }
                        }
                    }
                }

                const playButtonEl = document.getElementById('playButton');
                if (playButtonEl) playButtonEl.disabled = false;
                userInput.value = '';

            } catch (error) {
                console.error('Error:', error);
                document.getElementById('responseBox').innerHTML = 
                    `<span class="error-msg">抱歉，護理系統遇到問題: ${error.message}</span>`;
                setFoxState(null);
            } finally {
                document.getElementById('sendButton').disabled = false;
                userInput.disabled = false;
                const stopButtonElFinal = document.getElementById('stopButton');
                if (stopButtonElFinal) stopButtonElFinal.disabled = true;
                userInput.focus();
            }
        }

        async function replayLastResponse() {
            if (!lastResponse) return;

            audioQueue.stop();
            sentenceDetector.reset();

            const sentences = lastResponse.match(/[^。！？]+[。！？]/g) || [lastResponse];
            sentences.forEach((sentence, index) => {
                audioQueue.addToQueue(sentence, index);
            });
        }

        function stopAllAudio() {
            audioQueue.stop();
            if (window.ultraFastTTS) {
                window.ultraFastTTS.stop();
            }
        }

        let currentAnswerLevel = 'primary';

        function showLevelChangeNotification(level) {
            const levelNames = {
                primary: '小學程度',
                secondary: '中學程度',
                university: '大學程度',
                professional: '專業層級'
            };
            
            const levelIcons = {
                primary: '🌱',
                secondary: '🌿',
                university: '🌳',
                professional: '🎓'
            };
            
            // 創建通知元素
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(0.8);
                padding: 25px 40px;
                background: linear-gradient(135deg, #7FCB8A, #5DBB63);
                border-radius: 20px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 3000;
                opacity: 0;
                transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
                text-align: center;
            `;
            
            notification.innerHTML = `
                <div style="font-size: 48px; margin-bottom: 10px;">${levelIcons[level]}</div>
                <div style="color: white; font-size: 20px; font-weight: 700;">
                    已切換到: ${levelNames[level]}
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // 顯示動畫
            setTimeout(() => {
                notification.style.opacity = '1';
                notification.style.transform = 'translate(-50%, -50%) scale(1)';
            }, 10);
            
            // 自動隱藏
            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transform = 'translate(-50%, -50%) scale(0.8)';
                setTimeout(() => notification.remove(), 300);
            }, 2000);
        }

        function getPromptPrefix(level) {
            const prompts = {
                primary: '請用小學生都能明白嘅簡單詞彙,好似講故仔咁解釋:',
                secondary: '請用中學程度嘅語言,清楚詳細咁解釋:',
                university: '請用大學程度嘅語言,包含相關學術概念同理論:',
                professional: '請用專業術語同深入分析,提供專業層級嘅詳細回答:'
            };
            
            return prompts[level] || prompts.primary;
        }

        function openSettings() {
            document.getElementById('settingsPanel').classList.add('open');
            document.getElementById('overlay').classList.add('show');
        }

        function closeSettingsPanel() {
            document.getElementById('settingsPanel').classList.remove('open');
            document.getElementById('overlay').classList.remove('show');
        }

        function saveSettings() {
            const settings = {
                // AI 設置
                model: document.getElementById('modelSelect').value,
                voice: document.getElementById('voiceSelect').value,
                responseLength: document.getElementById('responseLengthSelect').value,
                autoSpeak: document.getElementById('autoSpeak').checked,
                
                // 語音識別設置
                asrEngine: document.getElementById('asrEngineSelect').value,
                wakeWord: document.getElementById('wakeWordToggle')?.checked || false,
                confidenceTimeout: document.getElementById('confidenceTimeoutSlider')?.value || 800,
                silenceThreshold: document.getElementById('silenceThresholdSlider')?.value || 1500,
                volumeThreshold: localStorage.getItem('volumeThreshold') || 30,
                
                // 機械臂連接
                robotWSUrl: document.getElementById('robotWSUrl')?.value || 'ws://localhost:8765',
                
                // 調試設置
                debugMode: document.getElementById('debugMode')?.checked || false,
                
                // 版本標記
                version: '2.0-nurse'
            };
            
            localStorage.setItem('foxAISettings', JSON.stringify(settings));
            debugLog('info', '設置已保存', settings);
        }

        function loadSettings() {
            const savedSettings = localStorage.getItem('foxAISettings');
            if (savedSettings) {
                try {
                    const settings = JSON.parse(savedSettings);
                    
                    // 加載 AI 設置
                    if (settings.model) document.getElementById('modelSelect').value = settings.model;
                    if (settings.voice) document.getElementById('voiceSelect').value = settings.voice;
                    if (settings.responseLength) document.getElementById('responseLengthSelect').value = settings.responseLength;
                    document.getElementById('autoSpeak').checked = settings.autoSpeak !== false;
                    
                    // 加載語音識別設置
                    if (settings.asrEngine) document.getElementById('asrEngineSelect').value = settings.asrEngine;
                    
                    const wakeWordToggle = document.getElementById('wakeWordToggle');
                    if (wakeWordToggle && settings.wakeWord) {
                        wakeWordToggle.checked = true;
                        if (wakeWordDetector) {
                            setTimeout(() => wakeWordDetector.start(), 1000);
                        }
                    }
                    
                    const confidenceSlider = document.getElementById('confidenceTimeoutSlider');
                    const confidenceValue = document.getElementById('confidenceTimeoutValue');
                    if (confidenceSlider && settings.confidenceTimeout) {
                        confidenceSlider.value = settings.confidenceTimeout;
                        if (confidenceValue) confidenceValue.textContent = `${settings.confidenceTimeout} ms`;
                    }
                    
                    const silenceSlider = document.getElementById('silenceThresholdSlider');
                    const silenceValue = document.getElementById('silenceThresholdValue');
                    if (silenceSlider && settings.silenceThreshold) {
                        silenceSlider.value = settings.silenceThreshold;
                        if (silenceValue) silenceValue.textContent = `${settings.silenceThreshold} ms`;
                    }
                    
                    // 加載機械臂設置
                    const robotWSUrl = document.getElementById('robotWSUrl');
                    if (robotWSUrl && settings.robotWSUrl) {
                        robotWSUrl.value = settings.robotWSUrl;
                    }
                    
                    // 加載調試設置
                    const debugModeCheckbox = document.getElementById('debugMode');
                    if (debugModeCheckbox && settings.debugMode) {
                        debugModeCheckbox.checked = true;
                        debugMode = true;
                    }
                    
                    debugLog('info', '設置已加載', settings);
                    
                } catch (e) {
                    console.error('❌ 載入設定錯誤:', e);
                }
            }
            else {
                const modelSelect = document.getElementById('modelSelect');
                if (modelSelect) {
                    modelSelect.value = 'together-mixtral';
                }
                const wakeWordToggle = document.getElementById('wakeWordToggle');
                if (wakeWordToggle) {
                    wakeWordToggle.checked = true;
                    if (wakeWordDetector) {
                        setTimeout(() => wakeWordDetector.start(), 500);
                    }
                }
            }
            
            // 加載統計
            updateStatistics();
        }

        function initAnswerLevelSetting() {
            const answerLevelSelect = document.getElementById('answerLevelSelect');
            if (answerLevelSelect) {
                answerLevelSelect.addEventListener('change', (e) => {
                    currentAnswerLevel = e.target.value;
                    saveSettings();
                    console.log(`🎓 回答層級已更新為: ${currentAnswerLevel}`);
                    showLevelChangeNotification(currentAnswerLevel);
                });
            }
        }

// ===== 按摩控制面板邏輯 =====

// 面板狀態管理
let controlPanelMode = 'quick'; // 'quick' 或 'voice'

// 初始化控制面板
function initMassageControlPanel() {
    // 模式切換按鈕
    const modeButtons = document.querySelectorAll('.mode-btn');
    modeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            switchControlMode(mode);
        });
    });
    
    // 快速方案按鈕
    const quickPresetBtn = document.getElementById('quickPresetBtn');
    if (quickPresetBtn) {
        quickPresetBtn.addEventListener('click', showQuickPresets);
    }
    
    // 執行按摩按鈕
    const executeBtn = document.getElementById('executeManualBtn');
    if (executeBtn) {
        executeBtn.addEventListener('click', executeManualMassage);
    }
    
    // 選擇框變化監聽（自動推薦）
    const bodyPartSelect = document.getElementById('bodyPartSelect');
    if (bodyPartSelect) {
        bodyPartSelect.addEventListener('change', handleBodyPartChange);
    }
}

// 切換控制模式
function switchControlMode(mode) {
    controlPanelMode = mode;
    
    // 更新按鈕狀態
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === mode);
    });
    
    // 切換面板顯示
    const panel = document.getElementById('massageControlPanel');
    const quickParams = document.querySelector('.quick-params-collapsible');
    const voiceInput = document.getElementById('userInput');
    const voiceButton = document.getElementById('voiceButton');
    
    if (mode === 'voice') {
        if (panel) panel.classList.add('hidden');
        if (quickParams) quickParams.open = false;
        if (voiceInput) voiceInput.focus();
        if (voiceButton) voiceButton.classList.add('pulse');
        addSystemMessage('💬 已切換到語音模式，請直接說出您的需求', 'info');
    } else {
        if (panel) panel.classList.remove('hidden');
        if (quickParams) quickParams.open = true;
        if (voiceButton) voiceButton.classList.remove('pulse');
        addSystemMessage('🎛️ 已切換到快速模式，請使用選擇框設定參數', 'info');
    }
}

// 處理部位變化（智能推薦）
function handleBodyPartChange(e) {
    const bodyPart = e.target.value;
    if (!bodyPart) return;
    
    // 根據部位推薦動作
    const recommendations = {
        '肩膀': { action: '揉捏', intensity: '適中' },
        '背部': { action: '推拿', intensity: '適中' },
        '腰部': { action: '指壓', intensity: '適中' },
        '腿部': { action: '敲打', intensity: '輕柔' },
        '頸部': { action: '推拿', intensity: '輕柔' },
        '手臂': { action: '揉捏', intensity: '輕柔' }
    };
    
    const rec = recommendations[bodyPart];
    if (rec) {
        // 自動填充推薦值
        document.getElementById('actionSelect').value = rec.action;
        document.getElementById('intensitySelect').value = rec.intensity;
        
        // 顯示提示
        addSystemMessage(`💡 根據${bodyPart}的特性，推薦使用「${rec.action}」動作，「${rec.intensity}」力度`, 'info');
    }
}

// 顯示快速方案選擇
function showQuickPresets() {
    const presets = [
        {
            name: '🏢 辦公室肩頸舒緩',
            bodyPart: '肩膀',
            action: '揉捏',
            intensity: '適中',
            duration: 5
        },
        {
            name: '🏃 運動後腿部放鬆',
            bodyPart: '腿部',
            action: '敲打',
            intensity: '輕柔',
            duration: 8
        },
        {
            name: '😴 睡前全身舒壓',
            bodyPart: '背部',
            action: '推拿',
            intensity: '輕柔',
            duration: 10
        },
        {
            name: '💪 深層腰部理療',
            bodyPart: '腰部',
            action: '指壓',
            intensity: '強力',
            duration: 8
        }
    ];
    
    // 創建方案選擇彈窗
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    `;
    
    modal.innerHTML = `
        <div style="
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        ">
            <h3 style="margin-bottom: 20px; color: var(--medical-blue-dark);">
                ⚡ 快速方案選擇
            </h3>
            <div class="preset-list">
                ${presets.map((preset, index) => `
                    <button class="preset-item" data-preset-index="${index}" style="
                        width: 100%;
                        padding: 15px;
                        margin-bottom: 10px;
                        background: linear-gradient(135deg, rgba(74, 144, 226, 0.1), rgba(126, 217, 195, 0.1));
                        border: 2px solid var(--secondary-color);
                        border-radius: 12px;
                        text-align: left;
                        cursor: pointer;
                        transition: var(--transition);
                    ">
                        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">
                            ${preset.name}
                        </div>
                        <div style="font-size: 13px; color: var(--text-secondary);">
                            ${preset.bodyPart} · ${preset.action} · ${preset.intensity} · ${preset.duration}分鐘
                        </div>
                    </button>
                `).join('')}
            </div>
            <button id="closePresetModal" style="
                width: 100%;
                padding: 12px;
                margin-top: 15px;
                background: var(--bg-secondary);
                border: none;
                border-radius: 12px;
                cursor: pointer;
            ">取消</button>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 綁定事件
    modal.querySelectorAll('.preset-item').forEach((btn, index) => {
        btn.addEventListener('click', () => {
            applyPreset(presets[index]);
            modal.remove();
        });
        
        // 懸停效果
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 4px 12px rgba(74, 144, 226, 0.3)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
    
    document.getElementById('closePresetModal').addEventListener('click', () => {
        modal.remove();
    });
    
    // 點擊背景關閉
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

// 應用快速方案
function applyPreset(preset) {
    document.getElementById('bodyPartSelect').value = preset.bodyPart;
    document.getElementById('actionSelect').value = preset.action;
    document.getElementById('intensitySelect').value = preset.intensity;
    document.getElementById('durationSelect').value = preset.duration;
    
    addSystemMessage(`✅ 已套用「${preset.name}」方案`, 'success');
    soundEffects.playConfirmSound();
}

// 執行手動設定的按摩
async function executeManualMassage() {
    // 獲取選擇的參數
    const bodyPart = document.getElementById('bodyPartSelect').value;
    const action = document.getElementById('actionSelect').value;
    const intensity = document.getElementById('intensitySelect').value;
    const duration = parseInt(document.getElementById('durationSelect').value);
    
    // 驗證參數
    if (!bodyPart || !action || !intensity || !duration) {
        addSystemMessage('⚠️ 請完整選擇所有按摩參數', 'warning');
        soundEffects.playErrorSound();
        return;
    }
    
    // 構建指令對象
    const command = {
        bodyPart,
        action,
        intensity,
        duration,
        rawText: `${bodyPart} ${action} ${intensity} ${duration}分鐘`,
        source: 'manual',
        confidence: 100
    };
    
    debugLog('command', '手動執行按摩指令', command);
    
    // 調用解析執行函數
    const userPrompt = `幫我${action}${bodyPart}，力度${intensity}，時間${duration}分鐘`;
    const aiResponse = `好的，為您安排${bodyPart}的${action}按摩，力度${intensity}，持續${duration}分鐘。\n\n[指令分類]\n部位: ${bodyPart}\n動作: ${action}\n力度: ${intensity}\n時間: ${duration}分鐘\n[/指令分類]`;
    const displayAiResponse = removeCommandBlocks(aiResponse);
    
    // 添加到對話記錄
    const responseBox = document.getElementById('responseBox');
    responseBox.innerHTML += `<div class="user-bubble message-bubble visible">${userPrompt}</div>`;
    responseBox.innerHTML += `<div class="fox-bubble message-bubble visible">${displayAiResponse}</div>`;
    responseBox.scrollTop = responseBox.scrollHeight;
    lastResponse = displayAiResponse;
    isInCommandBlock = false;
    
    // 執行指令
    await parseAndExecuteCommand(aiResponse, userPrompt);
}

// 從語音/文字輸入自動填充選擇框
function autoFillControlsFromText(text) {
    const command = commandParser.parse(text);
    
    if (command.bodyPart) {
        document.getElementById('bodyPartSelect').value = command.bodyPart;
    }
    if (command.action) {
        document.getElementById('actionSelect').value = command.action;
    }
    if (command.intensity) {
        document.getElementById('intensitySelect').value = command.intensity;
    }
    if (command.duration) {
        document.getElementById('durationSelect').value = command.duration;
    }
}

        // ===== 事件綁定 =====
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🚀 DOM載入完成，初始化事件監聽器...');
            
            // 初始化核心組件
            audioQueue = new OptimizedAudioPlayer();
            sentenceDetector = new SmartSentenceDetector();
            initAnswerLevelSetting();

            // 初始化控制面板
    initMassageControlPanel();
    
    // 默認顯示快速模式
    switchControlMode('quick');

            // Event listener for quick response buttons
            const quickResponseButtonsContainer = document.querySelector('.quick-response-buttons');
            if (quickResponseButtonsContainer) {
                quickResponseButtonsContainer.addEventListener('click', (e) => {
                    if (e.target.classList.contains('response-btn')) {
                        const response = e.target.dataset.response;
                        if (currentMassageSession && currentMassageSession.isWaitingForResponse) {
                            currentMassageSession.processVoiceResponse(response);
                        } else {
                            // If no session is active or waiting, treat it as a normal user input
                            const userInput = document.getElementById('userInput');
                            userInput.value = response;
                            sendMessage();
                        }
                    }
                });
            }
            
            // 獲取DOM元素
            const userInput = document.getElementById('userInput');
            const sendButton = document.getElementById('sendButton');
            const playButton = document.getElementById('playButton');
            const stopButton = document.getElementById('stopButton');
            const settingsBtn = document.getElementById('settingsBtn');
            const closeSettings = document.getElementById('closeSettings');
            const overlay = document.getElementById('overlay');
            const testSystemBtn = document.getElementById('testSystemBtn');
            const modelSelect = document.getElementById('modelSelect');
            const voiceSelect = document.getElementById('voiceSelect');
            const responseLengthSelect = document.getElementById('responseLengthSelect');
            const asrEngineSelect = document.getElementById('asrEngineSelect');
            const asrInfo = document.getElementById('asrInfo');
            const autoSpeak = document.getElementById('autoSpeak');
            const voiceButton = document.getElementById('voiceButton');
            const wakeWordToggle = document.getElementById('wakeWordToggle');
            const confidenceSlider = document.getElementById('confidenceTimeoutSlider');
            const confidenceValue = document.getElementById('confidenceTimeoutValue');
            const silenceSlider = document.getElementById('silenceThresholdSlider');
            const silenceValue = document.getElementById('silenceThresholdValue');
            const calibrateMicBtn = document.getElementById('calibrateMicBtn');
            const restartWakeWordBtn = document.getElementById('restartWakeWordBtn');

            if (wakeWordToggle) {
                wakeWordDetector = new WakeWordDetector();
                if (wakeWordDetector.init()) {
                    console.log('✅ 喚醒詞功能可用');

                    if (wakeWordToggle.checked) {
                        wakeWordDetector.start();
                        if (restartWakeWordBtn) restartWakeWordBtn.disabled = false;
                    }

                    wakeWordToggle.addEventListener('change', () => {
                        if (wakeWordToggle.checked) {
                            wakeWordDetector.start();
                            if (restartWakeWordBtn) restartWakeWordBtn.disabled = false;
                        } else {
                            wakeWordDetector.stop();
                            if (restartWakeWordBtn) restartWakeWordBtn.disabled = true;
                        }
                        saveSettings();
                    });

                } else {
                    wakeWordToggle.disabled = true;
                    if (restartWakeWordBtn) restartWakeWordBtn.disabled = true;
                    const wakeWordLabel = document.querySelector('label[for="wakeWordToggle"]');
                    if (wakeWordLabel) {
                        wakeWordLabel.classList.add('disabled');
                    }
                }
            }

            // Event listener for the new manual restart button
            if (restartWakeWordBtn) {
                restartWakeWordBtn.addEventListener('click', () => {
                    if (wakeWordDetector) {
                        console.log('🔄 Manual restart triggered');
                        wakeWordDetector.restart();
                    }
                });
            }

            // Event listeners for new STT settings
            if (confidenceSlider) {
                confidenceSlider.addEventListener('input', () => {
                    confidenceValue.textContent = `${confidenceSlider.value} ms`;
                });
                confidenceSlider.addEventListener('change', saveSettings);
            }

            if (silenceSlider) {
                silenceSlider.addEventListener('input', () => {
                    silenceValue.textContent = `${silenceSlider.value} ms`;
                });
                silenceSlider.addEventListener('change', saveSettings);
            }

            if (calibrateMicBtn) {
                calibrateMicBtn.addEventListener('click', calibrateMicrophone);
            }

            // 知識庫管理按鈕
            const manageKnowledgeBtn = document.getElementById('manageKnowledgeBtn');
            if (manageKnowledgeBtn) {
                manageKnowledgeBtn.addEventListener('click', () => {
                    document.getElementById('knowledgePanel').classList.add('open');
                    loadQAPairs();
                });
            }
            
            // 關閉知識庫管理面板
            const closeKnowledge = document.getElementById('closeKnowledge');
            if (closeKnowledge) {
                closeKnowledge.addEventListener('click', () => {
                    document.getElementById('knowledgePanel').classList.remove('open');
                });
            }

            userInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    console.log('📤 Enter鍵觸發傳送');
                    sendMessage();
                }
            });

            // 自動調整textarea高度
            userInput.addEventListener('input', function() {
                this.style.height = '65px';
                const scrollHeight = this.scrollHeight;
                if (scrollHeight > 65 && scrollHeight <= 100) {
                    this.style.height = scrollHeight + 'px';
                } else if (scrollHeight > 100) {
                    this.style.height = '100px';
                }
            });

            // 按鈕事件
            sendButton.addEventListener('click', () => {
                console.log('📤 傳送按鈕點擊');
                sendMessage();
            });

            if (playButton) {
                playButton.addEventListener('click', () => {
                    console.log('🔊 播放按鈕點擊');
                    replayLastResponse();
                });
            }

            if (stopButton) {
                stopButton.addEventListener('click', async () => {
                    console.log('⏹️ 停止按鈕點擊');
                    stopAllAudio();
                    if (sessionManager) {
                        await sessionManager.stop('user-stop');
                    }
                });
            }

            settingsBtn.addEventListener('click', () => {
                console.log('⚙️ 設定按鈕點擊');
                openSettings();
            });

            if (closeSettings) {
                closeSettings.addEventListener('click', closeSettingsPanel);
            }

            if (overlay) {
                overlay.addEventListener('click', closeSettingsPanel);
            }

            if (testSystemBtn) {
                testSystemBtn.addEventListener('click', testSystem);
            }

            // ASR Engine change handler
            if (asrEngineSelect) {
                asrEngineSelect.addEventListener('change', async (e) => {
                    currentASREngine = e.target.value;

                    // Stop any ongoing recognition
                    stopRecording();

                    // Update UI
                    if (currentASREngine === 'browser') {
                        asrInfo.textContent = '使用瀏覽器內建語音識別，完全免費㗎！';
                        // Initialize browser recognition
                        initBrowserSpeechRecognition();
                    } else if (currentASREngine === 'xunfei') {
                        asrInfo.textContent = '使用訊飛語音識別，更準確咁聽明你講嘅嘢！';
                        voiceButton.disabled = true;
                        asrInfo.textContent += '（需要伺服器配置）';
                    }
                    saveSettings();
                });
            }

            // Voice button events
            if (voiceButton) {
                // 桌面版:按住錄音
                voiceButton.addEventListener('mousedown', (e) => {
                    e.preventDefault();
                    startRecording();
                });

                voiceButton.addEventListener('mouseup', (e) => {
                    e.preventDefault();
                    stopRecording();
                });

                // 移動版:觸控錄音
                voiceButton.addEventListener('touchstart', (e) => {
                    e.preventDefault();
                    startRecording();
                });

                voiceButton.addEventListener('touchend', (e) => {
                    e.preventDefault();
                    stopRecording();
                });

                // 防止意外離開按鈕時錄音繼續
                voiceButton.addEventListener('mouseleave', (e) => {
                    if (isRecording) {
                        stopRecording();
                    }
                });
            }

            // 在這裡添加模型選擇變更事件 👇
            if (modelSelect) {
                modelSelect.addEventListener('change', function() {
                    const selectedModel = this.value;
                    const modelInfo = document.getElementById('currentModelInfo');
                    
                    if (modelInfo) {
                        switch(selectedModel) {
                            case 'gemini-2.5-flash':
                                modelInfo.textContent = '使用 Gemini 2.5 Flash - 最快速的回應';
                                break;
                            case 'gemini-2.0-flash':
                                modelInfo.textContent = '使用 Gemini 2.0 Flash - 穩定版本';
                                break;
                            case 'deepseek-chat':
                                modelInfo.textContent = '使用 DeepSeek Chat - 智慧狐狸';
                                break;
                            case 'together-llama-70b':
                                modelInfo.textContent = '使用 Llama 3.1 70B - 羊駝狐狸';
                                break;
                            case 'together-mixtral':
                                modelInfo.textContent = '使用 Mixtral 8x7B - 混合狐狸';
                                break;
                            case 'together-qwen':
                                modelInfo.textContent = '使用 Qwen 72B (Together)';
                                break;
                            case 'qwen-turbo':
                                modelInfo.textContent = '使用 Qwen Turbo - 飛速狐狸';
                                break;
                            case 'qwen-plus':
                                modelInfo.textContent = '使用 Qwen Plus - 超級狐狸';
                                break;
                            default:
                                modelInfo.textContent = `當前模型：${selectedModel}`;
                        }
                    }
                    
                    // 同時觸發保存設定
                    saveSettings();
                });
            }

            // 設定變更事件
            if (modelSelect) modelSelect.addEventListener('change', saveSettings);
            if (voiceSelect) voiceSelect.addEventListener('change', saveSettings);
            if (responseLengthSelect) responseLengthSelect.addEventListener('change', saveSettings);
            if (autoSpeak) autoSpeak.addEventListener('change', saveSettings);

        // 小狐狸互動
        document.getElementById('nurseAssistant').addEventListener('click', async () => {
            showFoxReaction('happy', 2000);
            spawnParticles('💙', 8);
            
            const greetings = [
                "您好！需要什麼護理服務嗎？",
                "我隨時準備為您服務～",
                "請告訴我您哪裡不舒服？",
                "今天感覺如何？需要放鬆一下嗎？",
                "智能護理助手隨時待命！",
                "讓我幫您舒緩疲勞吧！"
            ];
            const greeting = greetings[Math.floor(Math.random() * greetings.length)];
            
            const autoSpeakCheckbox = document.getElementById('autoSpeak');
            const originalAutoSpeak = autoSpeakCheckbox.checked;
            autoSpeakCheckbox.checked = false;
            
            addFoxMessage(greeting);
            
            autoSpeakCheckbox.checked = originalAutoSpeak;
            
            if (originalAutoSpeak) {
                await playCantoneseTTS(greeting);
            }
        });

            console.log('✅ 所有事件監聽器已綁定');

            // 載入設定
            loadSettings();
        });

        // ===== 初始化 =====

        window.addEventListener('load', async () => {
            console.log('🌐 頁面載入完成');
            
            // Hide loading animation first
            setTimeout(() => {
                document.getElementById('loadingOverlay').classList.add('hidden');
                // Play welcome animation
                showFoxReaction('happy', 4000);
                spawnParticles('🌲', 15);
                createFireflies();
            }, 2000);
            
            // Initialize connection with proper port detection
            await initializeConnection();
            
            // Set up periodic connection checks
            setInterval(checkConnection, 5000);
            setInterval(updateAPIStatus, 30000);

            // Check if running from file:// protocol
            if (window.location.protocol === 'file:') {
                console.warn('建議使用 HTTP 伺服器運行此應用以獲得更好嘅體驗');
                const notice = document.createElement('div');
                notice.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: #FFE4B5;
                    color: #8B4513;
                    padding: 10px 20px;
                    border-radius: 20px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    font-size: 14px;
                    z-index: 100;
                `;
                notice.innerHTML = `
                    💡 提示：建議使用以下方式開啟頁面以避免權限問題：<br>
                    <code>python -m http.server 8000</code> 然後訪問 <code>http://localhost:8000</code>
                `;
                document.body.appendChild(notice);
                setTimeout(() => notice.remove(), 10000);
            }

            // Microphone permission will be initialized on first use.

            // Initialize based on selected engine
            if (currentASREngine === 'browser') {
                initBrowserSpeechRecognition();
            }
            
            // Focus input box
            const userInput = document.getElementById('userInput');
            if (userInput) userInput.focus();

            console.log('✅ 初始化完成');
        });


        // Clean up on page unload
        window.addEventListener('beforeunload', () => {
            if (sharedMicStream) {
                sharedMicStream.getTracks().forEach(track => {
                    track.stop();
                });
            }
            isMassageSessionActive = false;
        });

        // 全域 setImmediate polyfill
        if (typeof window.setImmediate === 'undefined') {
            window.setImmediate = function(callback) {
                return setTimeout(callback, 0);
            };
        }

        // 調試功能 - 手動顯示天氣
        window.showWeather = function() {
            const weatherEl = document.getElementById('miniWeather');
            if (weatherEl) {
                // 移除所有可能的隱藏樣式
                weatherEl.style.display = 'flex';
                weatherEl.style.opacity = '1';
                weatherEl.style.visibility = 'visible';
                weatherEl.classList.remove('hidden');
                
                // 設置測試數據
                document.getElementById('weatherIcon').textContent = '☀️';
                document.getElementById('weatherTemp').textContent = '28°';
                document.getElementById('weatherDesc').textContent = '晴朗';
                
                console.log('✅ 天氣已強制顯示');
                console.log('Element styles:', window.getComputedStyle(weatherEl));
            } else {
                console.error('❌ 找不到天氣元素');
            }
        };

        console.log('👩‍⚕️ 智能按摩護理助手極致融合版腳本載入完成');

        // ===== 指令解析與執行 =====
        async function parseAndExecuteCommand(responseText, userPrompt) {
            debugLog('parse', '開始解析用戶指令', { userPrompt, responseText: responseText.substring(0, 100) });
            
            // 1. 嘗試從 AI 回應中提取結構化指令
            const commandMatch = responseText.match(/\[指令分類\]([\s\S]*?)\[\/指令分類\]/);
            
            let command = null;
            
            if (commandMatch) {
                // AI 提供了結構化指令
                const commandBlock = commandMatch[1];
                debugLog('parse', '檢測到 AI 結構化指令', { commandBlock });
                
                command = {
                    bodyPart: extractField(commandBlock, '部位'),
                    action: extractField(commandBlock, '動作'),
                    intensity: extractField(commandBlock, '力度'),
                    duration: parseInt(extractField(commandBlock, '時間')) || 5,
                    rawText: userPrompt,
                    aiResponse: responseText,
                    source: 'ai'
                };
            } else {
                // 使用本地解析器
                debugLog('parse', '使用本地解析器解析指令');
                command = commandParser.parse(userPrompt);
                command.source = 'parser';
                
                // 格式化指令（填充默認值）
                if (commandParser.isValid(command)) {
                    command = commandParser.formatCommand(command);
                }
            }
            
            debugLog('parse', '指令解析完成', command);
            
            // 2. 驗證指令有效性
            if (!isValidCommand(command)) {
                debugLog('parse', '指令無效，跳過執行', { reason: '缺少必要參數' });
                
                if (command.bodyPart && !command.action) {
                    addSystemMessage('💡 提示：請告訴我您想要什麼類型的按摩（揉捏、敲打、推拿、指壓）');
                }
                return;
            }
            
            await handleMassageCommand(command, {
                userPrompt,
                responseText
            });
        }

        async function handleMassageCommand(command, meta) {
            if (command.emergency) {
                addSystemMessage('⛔ 已收到停止指令，立即停止按摩。', 'warning');
                await sendRobotCommand('stop');
                if (sessionManager) {
                    await sessionManager.stop('emergency', { notifyRobot: false });
                }
                return;
            }

            if (!consentGranted) {
                pendingCommand = { command, meta };
                showConsentPrompt();
                return;
            }

            if (!safetyReminderShown) {
                showSafetyReminder();
                safetyReminderShown = true;
            }

            try {
                await executeMassageCommand(command, meta);
            } catch (error) {
                console.error('❌ Massage execution error:', error);
                // Ensure flag is cleared on error
                isMassageSessionActive = false;
            }
        }

        async function executeMassageCommand(command, meta) {
            debugLog('safety', '開始安全檢查', command);
            const safetyResult = safetyChecker.checkCommand(command);

            if (!safetyResult.safe) {
                debugLog('safety', '安全檢查失敗', safetyResult);
                soundEffects.playErrorSound();

                const errorMsg = '⚠️ 安全檢查未通過：\n' + safetyResult.errors.join('\n');
                addSystemMessage(errorMsg, 'error');
                return;
            }

            if (safetyResult.warnings.length > 0) {
                debugLog('safety', '安全警告', safetyResult.warnings);
                const warningMsg = '⚠️ 提醒：\n' + safetyResult.warnings.join('\n');
                addSystemMessage(warningMsg, 'warning');
            }

            debugLog('safety', '安全檢查通過');

            addConfirmationMessage(command);
            soundEffects.playStartSound();

            safetyChecker.recordOperation(command);
            updateStatistics();

            // 🎤 Start interactive session with auto voice
            currentMassageSession = new InteractiveMassageSession(command);
            currentMassageSession.start();
            
            // Enable quick response buttons
            showQuickResponseButtons();
            const liveControls = document.querySelector('.live-controls');
            if(liveControls) liveControls.style.display = 'flex';
            
            console.log('✅ Interactive massage session started with auto voice listening');

            const started = await sendRobotCommand('start', {
                body_part: command.bodyPart,
                action: command.action,
                intensity: command.intensity,
                duration: command.duration
            });

            if (!started) {
                addSystemMessage('⚠️ 未能連線至機械臂，已啟用模擬模式協助您感受流程。', 'warning');
            }

            // The new session manager handles its own simulation/execution flow.
            // await simulateMassageExecution(command);
        }

        function showConsentPrompt() {
            if (consentPromptVisible) return;
            const responseBox = document.getElementById('responseBox');
            if (!responseBox) return;

            consentPromptVisible = true;

            const prompt = document.createElement('div');
            prompt.id = 'consentPrompt';
            prompt.className = 'command-confirmation';
            prompt.style.cssText = `
                margin-top: 15px;
                padding: 16px;
                border-radius: 14px;
                border: 1px solid var(--tech-border);
                background: linear-gradient(135deg, rgba(127, 203, 138, 0.12), rgba(135, 206, 235, 0.12));
            `;

            prompt.innerHTML = `
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
                    <span style="font-size:22px;">🛡️</span>
                    <div>
                        <div style="font-weight:600;color:var(--medical-blue-dark);">開始前安全確認</div>
                        <div style="font-size:13px;color:var(--text-secondary);margin-top:4px;">
                            請確認您目前沒有皮膚破損、近期手術或明顯疼痛。若過程中感到不適，可隨時說「停」或按下停止鍵。
                        </div>
                    </div>
                </div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <button data-action="agree" class="preset-item" style="padding:10px 18px;background:var(--secondary-color);color:white;border:none;border-radius:10px;cursor:pointer;">✅ 我已確認，請開始</button>
                    <button data-action="decline" class="preset-item" style="padding:10px 18px;background:var(--error);color:white;border:none;border-radius:10px;cursor:pointer;">⚠️ 需要再評估</button>
                </div>
            `;

            prompt.querySelector('[data-action="agree"]').addEventListener('click', () => handleConsentResponse(true));
            prompt.querySelector('[data-action="decline"]').addEventListener('click', () => handleConsentResponse(false));

            responseBox.appendChild(prompt);
            responseBox.scrollTop = responseBox.scrollHeight;
        }

        function handleConsentResponse(accepted) {
            removeElement('consentPrompt');
            consentPromptVisible = false;

            if (!accepted) {
                addSystemMessage('✅ 已取消本次按摩。如有不適，請儘速休息或聯絡專業人員。', 'info');
                pendingCommand = null;
                return;
            }

            consentGranted = true;
            addSystemMessage('✅ 感謝您的確認，我會隨時留意您的狀態。', 'success');

            if (pendingCommand) {
                const { command, meta } = pendingCommand;
                pendingCommand = null;
                handleMassageCommand(command, meta);
            }
        }

        function showSafetyReminder() {
            addSystemMessage('🛟 安全提醒：若感到不適，請立即說「停」、「太痛」或按下⏹️停止鍵，我會馬上為您中止或調整。', 'warning');
        }



        function removeElement(id) {
            const element = document.getElementById(id);
            if (element && element.parentNode) {
                element.parentNode.removeChild(element);
            }
        }

        function extractField(text, fieldName) {
            const regex = new RegExp(`${fieldName}\s*[:：]\s*([^\n]+)`);
            const match = text.match(regex);
            return match ? match[1].trim() : null;
        }

        function isValidCommand(command) {
            // 緊急停止指令總是有效
            if (command.emergency) return true;
            
            // 檢查必要參數
            return command.bodyPart && 
                   command.action && 
                   command.intensity && 
                   command.duration > 0 &&
                   command.duration <= 10;
        }

        function addSystemMessage(message, type = 'info') {
            const responseBox = document.getElementById('responseBox');
            
            const typeStyles = {
                'info': 'background: rgba(74, 144, 226, 0.1); border-left-color: var(--primary-color);',
                'warning': 'background: rgba(243, 156, 18, 0.1); border-left-color: var(--warning);',
                'error': 'background: rgba(231, 76, 60, 0.1); border-left-color: var(--error);',
                'success': 'background: rgba(82, 200, 159, 0.1); border-left-color: var(--success);'
            };
            
            const typeIcons = {
                'info': 'ℹ️',
                'warning': '⚠️',
                'error': '❌',
                'success': '✅'
            };
            
            const msgDiv = document.createElement('div');
            msgDiv.style.cssText = `
                margin: 15px 0;
                padding: 12px 15px;
                border-left: 4px solid;
                border-radius: 8px;
                font-size: 14px;
                line-height: 1.6;
                ${typeStyles[type]}
            `;
            
            msgDiv.innerHTML = `<strong>${typeIcons[type]}</strong> ${message.replace(/\n/g, '<br>')}`;
            
            responseBox.appendChild(msgDiv);
            responseBox.scrollTop = responseBox.scrollHeight;
        }

        function addConfirmationMessage(command) {
            const responseBox = document.getElementById('responseBox');
            
            const confirmDiv = document.createElement('div');
            confirmDiv.className = 'command-confirmation';
            confirmDiv.style.cssText = `
                margin-top: 15px;
                padding: 15px;
                background: linear-gradient(135deg, rgba(82, 200, 159, 0.15), rgba(74, 144, 226, 0.15));
                border-left: 44px solid var(--secondary-color);
                border-radius: 12px;
                font-size: 14px;
                position: relative;
                overflow: hidden;
            `;
            
            // 添加動畫背景
            confirmDiv.innerHTML = `
                <div style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: radial-gradient(circle, rgba(126, 217, 195, 0.3), transparent); border-radius: 50%; transform: translate(30%, -30%);"></div>
                
                <div style="position: relative; z-index: 1;">
                    <div style="font-weight: 600; color: var(--medical-blue-dark); margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 20px;">📋</span>
                        <span>按摩方案已確認</span>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: auto 1fr; gap: 10px 15px; color: var(--text-primary);">
                        <span style="color: var(--text-secondary);">🎯 部位：</span>
                        <span style="font-weight: 600;">${command.bodyPart}</span>
                        
                        <span style="color: var(--text-secondary);">💆 動作：</span>
                        <span style="font-weight: 600;">${command.action}</span>
                        
                        <span style="color: var(--text-secondary);">💪 力度：</span>
                        <span style="font-weight: 600;">${command.intensity}</span>
                        
                        <span style="color: var(--text-secondary);">⏱️ 時長：</span>
                        <span style="font-weight: 600;">${command.duration} 分鐘</span>
                    </div>
                    
                    ${command.source === 'parser' ? `
                        <div style="margin-top: 10px; padding: 8px; background: rgba(255, 255, 255, 0.5); border-radius: 6px; font-size: 12px; color: var(--text-secondary);">
                            <span style="color: var(--primary-color);">💡</span> 提示：部分參數由系統自動推薦
                        </div>
                    ` : ''}
                </div>
            `;
            
            responseBox.appendChild(confirmDiv);
            responseBox.scrollTop = responseBox.scrollHeight;
            
            // 添加進入動畫
            setTimeout(() => {
                confirmDiv.style.animation = 'slideInFromRight 0.5s ease-out';
            }, 10);
        }

        function createEmergencyStopButton() {
            if (document.getElementById('emergencyStopBtn')) return;

            const stopButton = document.createElement('button');
            stopButton.id = 'emergencyStopBtn';
            stopButton.innerHTML = '🛑 緊急停止';
            
            stopButton.style.cssText = `
                position: fixed;
                bottom: 100px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 9999;
                padding: 15px 30px;
                font-size: 20px;
                font-weight: bold;
                color: white;
                background-color: #e74c3c;
                border: 2px solid #c0392b;
                border-radius: 25px;
                cursor: pointer;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                transition: all 0.2s ease;
                animation: pulse 2s infinite;
            `;

            stopButton.onmouseover = () => { stopButton.style.backgroundColor = '#c0392b'; };
            stopButton.onmouseout = () => { stopButton.style.backgroundColor = '#e74c3c'; };

            stopButton.addEventListener('click', () => {
                if (currentMassageSession) {
                    currentMassageSession.emergencyStop();
                }
            });

            document.body.appendChild(stopButton);

            const styleSheet = document.createElement("style");
            styleSheet.id = 'emergencyBtnStyles';
            styleSheet.innerText = `
                @keyframes pulse {
                    0% { transform: translateX(-50%) scale(1); }
                    50% { transform: translateX(-50%) scale(1.05); }
                    100% { transform: translateX(-50%) scale(1); }
                }
            `;
            document.head.appendChild(styleSheet);
        }

        function removeEmergencyStopButton() {
            const stopButton = document.getElementById('emergencyStopBtn');
            if (stopButton) {
                stopButton.remove();
            }
            const styleSheet = document.getElementById('emergencyBtnStyles');
            if (styleSheet) {
                styleSheet.remove();
            }
        }

        // ===== 按摩指令解析器 (增強版) =====
        class MassageCommandParser {
            constructor() {
                // 部位關鍵詞（含同義詞）
                this.bodyParts = {
                    '肩膀': ['肩膀', '膊頭', '肩部', '肩胛', '膊', '肩'],
                    '背部': ['背', '背部', '後背', '脊椎', '背脊', '上背', '下背'],
                    '腰部': ['腰', '腰部', '腰椎', '腰骨', '腰間'],
                    '腿部': ['腿', '腿部', '大腿', '小腿', '腳', '足'],
                    '頸部': ['頸', '頸部', '脖子', '頸椎', '頸肩'],
                    '手臂': ['手臂', '手', '前臂', '上臂', '臂', '手肘']
                };
                
                // 動作關鍵詞
                this.actions = {
                    '揉捏': ['揉', '揉捏', '按揉', '捏'],
                    '敲打': ['敲', '敲打', '拍打', '拍'],
                    '推拿': ['推', '推拿', '推按', '推壓'],
                    '指壓': ['壓', '指壓', '按壓', '點壓', '按'],
                    '推油': ['推油', '精油', '油壓', '潤滑']
                };
                
                // 力度關鍵詞
                this.intensity = {
                    '輕柔': ['輕', '輕柔', '輕輕', '溫柔', '軟', '慢'],
                    '適中': ['適中', '正常', '中等', '普通'],
                    '強力': ['強', '大力', '用力', '重', '深層', '深', '硬']
                };
                
                // 症狀關鍵詞（用於推薦）
                this.symptoms = {
                    '痛': { parts: ['肩膀', '腰部', '背部'], action: '指壓', intensity: '適中' },
                    '酸': { parts: ['肩膀', '腰部', '腿部'], action: '揉捏', intensity: '輕柔' },
                    '緊': { parts: ['肩膀', '背部', '頸部'], action: '推拿', intensity: '適中' },
                    '累': { parts: ['腿部', '手臂'], action: '敲打', intensity: '輕柔' },
                    '僵硬': { parts: ['肩膀', '頸部', '背部'], action: '推拿', intensity: '強力' }
                };
                
                // 時間關鍵詞
                this.timePattern = /(\d+)\s*(分鐘|分|min|mins|minute|minutes)/i;
            }
            
            parse(text) {
                const command = {
                    bodyPart: null,
                    action: null,
                    intensity: null,
                    duration: null,
                    symptoms: [],
                    rawText: text,
                    confidence: 0
                };
                
                let confidenceScore = 0;
                
                // 1. 解析部位
                for (const [key, keywords] of Object.entries(this.bodyParts)) {
                    for (const kw of keywords) {
                        if (text.includes(kw)) {
                            command.bodyPart = key;
                            confidenceScore += 25;
                            break;
                        }
                    }
                    if (command.bodyPart) break;
                }
                
                // 2. 解析動作
                for (const [key, keywords] of Object.entries(this.actions)) {
                    for (const kw of keywords) {
                        if (text.includes(kw)) {
                            command.action = key;
                            confidenceScore += 25;
                            break;
                        }
                    }
                    if (command.action) break;
                }
                
                // 3. 解析力度
                for (const [key, keywords] of Object.entries(this.intensity)) {
                    for (const kw of keywords) {
                        if (text.includes(kw)) {
                            command.intensity = key;
                            confidenceScore += 20;
                            break;
                        }
                    }
                    if (command.intensity) break;
                }
                
                // 4. 解析時間
                const timeMatch = text.match(this.timePattern);
                if (timeMatch) {
                    command.duration = parseInt(timeMatch[1]);
                    confidenceScore += 15;
                }
                
                // 5. 解析症狀
                for (const [symptom, recommendation] of Object.entries(this.symptoms)) {
                    if (text.includes(symptom)) {
                        command.symptoms.push(symptom);
                        // 如果沒有明確部位，使用推薦
                        if (!command.bodyPart && recommendation.parts.length > 0) {
                            command.bodyPart = recommendation.parts[0];
                            confidenceScore += 10;
                        }
                        // 如果沒有明確動作，使用推薦
                        if (!command.action) {
                            command.action = recommendation.action;
                            confidenceScore += 10;
                        }
                        // 如果沒有明確力度，使用推薦
                        if (!command.intensity) {
                            command.intensity = recommendation.intensity;
                            confidenceScore += 10;
                        }
                    }
                }
                
                // 6. 檢查緊急停止
                if (text.includes('停止') || text.includes('停') || 
                    text.includes('暫停') || text.includes('唔要') || 
                    text.includes('不要') || text.includes('痛')) {
                    command.emergency = true;
                    confidenceScore = 100;
                }
                
                command.confidence = Math.min(confidenceScore, 100);
                
                return command;
            }
            
            isValid(command) {
                // 緊急停止指令總是有效
                if (command.emergency) return true;
                
                // 至少需要部位，且信心度 >= 40%
                return command.bodyPart !== null && command.confidence >= 40;
            }
            
            formatCommand(command) {
                // 填充缺失的參數
                if (command.bodyPart && !command.action) {
                    command.action = this.getDefaultAction(command.bodyPart);
                }
                if (!command.intensity) {
                    command.intensity = '適中';
                }
                if (!command.duration) {
                    command.duration = 5;  // 默認5分鐘
                }
                
                return command;
            }
            
            getDefaultAction(bodyPart) {
                const defaults = {
                    '肩膀': '揉捏',
                    '背部': '推拿',
                    '腰部': '指壓',
                    '腿部': '敲打',
                    '頸部': '推拿',
                    '手臂': '揉捏'
                };
                return defaults[bodyPart] || '揉捏';
            }
            
            getSuggestions(command) {
                // 根據部位和症狀提供建議
                const suggestions = [];
                
                if (command.symptoms.includes('痛')) {
                    suggestions.push('建議先使用輕柔力度，如果可以接受再逐漸增強');
                }
                
                if (command.bodyPart === '腰部') {
                    suggestions.push('腰部按摩時請保持舒適姿勢，避免過度用力');
                }
                
                if (command.duration > 8) {
                    suggestions.push('單次按摩建議不超過8分鐘，以免造成肌肉疲勞');
                }
                
                return suggestions;
            }
        }

        // 初始化解析器
        const commandParser = new MassageCommandParser();

        // ===== 安全檢查系統 =====
        class SafetyChecker {
            constructor() {
                this.maxForce = 30;  // 最大力度 (N)
                this.maxDuration = 10;  // 最大單次時長 (分鐘)
                this.cooldownTime = 3;  // 冷卻時間 (分鐘)
                this.lastOperationTime = null;
                this.operationHistory = [];
                this.consecutiveOperations = 0;
                this.maxConsecutiveOps = 3;  // 連續操作上限
                this.dailyLimit = 6;  // 每日操作上限
                
                // 載入今日歷史
                this.loadTodayHistory();
            }
            
            loadTodayHistory() {
                const today = new Date().toDateString();
                const stored = localStorage.getItem('massageHistory');
                
                if (stored) {
                    const history = JSON.parse(stored);
                    this.operationHistory = history.filter(op => {
                        const opDate = new Date(op.timestamp).toDateString();
                        return opDate === today;
                    });
                }
            }
            
            checkCommand(command) {
                const errors = [];
                const warnings = [];
                
                // 1. 檢查力度
                const intensityMap = { '輕柔': 10, '適中': 20, '強力': 30 };
                const force = intensityMap[command.intensity] || 20;
                if (force > this.maxForce) {
                    errors.push('力度超過安全限制');
                }
                
                // 2. 檢查時長
                if (command.duration > this.maxDuration) {
                    errors.push(`單次時長不可超過${this.maxDuration}分鐘`);
                } else if (command.duration > 8) {
                    warnings.push('建議單次按摩時間控制在8分鐘以內');
                }
                
                // 3. 檢查冷卻時間
                if (this.lastOperationTime) {
                    const timeSince = (Date.now() - this.lastOperationTime) / 60000;
                    if (timeSince < this.cooldownTime) {
                        const remaining = Math.ceil(this.cooldownTime - timeSince);
                        errors.push(`請等待${remaining}分鐘後再進行下次按摩`);
                    }
                }
                
                // 4. 檢查連續操作次數
                if (this.consecutiveOperations >= this.maxConsecutiveOps) {
                    errors.push('已連續操作3次，請休息15分鐘後再繼續');
                }
                
                // 5. 檢查每日限制 (已禁用)
                /*
                if (this.operationHistory.length >= this.dailyLimit) {
                    errors.push(`今日已達到${this.dailyLimit}次按摩上限，請明天再來`);
                }
                */
                
                // 6. 特殊部位檢查
                if (command.bodyPart === '頸部' && command.intensity === '強力') {
                    errors.push('頸部不建議使用強力按摩，請改用適中或輕柔力度');
                }
                
                // 7. 時長與力度組合檢查
                if (command.duration >= 8 && command.intensity === '強力') {
                    warnings.push('長時間強力按摩可能造成肌肉疲勞，建議調整參數');
                }
                
                return {
                    safe: errors.length === 0,
                    errors: errors,
                    warnings: warnings,
                    canProceed: errors.length === 0
                };
            }
            
            recordOperation(command) {
                const operation = {
                    timestamp: Date.now(),
                    bodyPart: command.bodyPart,
                    action: command.action,
                    intensity: command.intensity,
                    duration: command.duration
                };
                
                this.lastOperationTime = Date.now();
                this.operationHistory.push(operation);
                this.consecutiveOperations++;
                
                // 保存到 localStorage
                localStorage.setItem('massageHistory', JSON.stringify(this.operationHistory));
                
                // 15分鐘後重置連續操作計數
                setTimeout(() => {
                    this.consecutiveOperations = Math.max(0, this.consecutiveOperations - 1);
                }, 15 * 60 * 1000);
            }
            
            getStatistics() {
                const stats = {
                    todayCount: this.operationHistory.length,
                    remainingToday: Math.max(0, this.dailyLimit - this.operationHistory.length),
                    consecutiveOps: this.consecutiveOperations,
                    lastOperation: this.lastOperationTime,
                    favoriteBodyPart: this.getMostFrequentBodyPart()
                };
                
                return stats;
            }
            
            getMostFrequentBodyPart() {
                if (this.operationHistory.length === 0) return '無記錄';
                
                const counts = {};
                this.operationHistory.forEach(op => {
                    counts[op.bodyPart] = (counts[op.bodyPart] || 0) + 1;
                });
                
                return Object.keys(counts).reduce((a, b) => 
                    counts[a] > counts[b] ? a : b
                );
            }
            
            reset() {
                this.consecutiveOperations = 0;
                this.lastOperationTime = null;
            }
        }

        // 初始化安全檢查器
        const safetyChecker = new SafetyChecker();

        // 更新統計顯示
        function updateStatistics() {
            const stats = safetyChecker.getStatistics();
            
            document.getElementById('statTodayCount').textContent = stats.todayCount;
            document.getElementById('statRemaining').textContent = stats.remainingToday;
            document.getElementById('statFavoritePart').textContent = stats.favoriteBodyPart;
            document.getElementById('statConsecutive').textContent = stats.consecutiveOps;
        }



        // ===== 語音提示音效 =====
        class SoundEffects {
            constructor() {
                this.audioContext = null;
            }
            
            init() {
                if (!this.audioContext) {
                    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
            }
            
            playBeep(frequency = 440, duration = 200, volume = 0.3) {
                this.init();
                
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
                oscillator.type = 'sine';
                
                gainNode.gain.setValueAtTime(volume, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration / 1000);
                
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + duration / 1000);
            }
            
            // 按摩開始音效
            playStartSound() {
                this.playBeep(523.25, 100); // C5
                setTimeout(() => this.playBeep(659.25, 100), 120); // E5
                setTimeout(() => this.playBeep(783.99, 150), 240); // G5
            }
            
            // 按摩完成音效
            playCompleteSound() {
                this.playBeep(783.99, 100); // G5
                setTimeout(() => this.playBeep(659.25, 100), 120); // E5
                setTimeout(() => this.playBeep(523.25, 200), 240); // C5
            }
            
            // 錯誤音效
            playErrorSound() {
                this.playBeep(200, 300, 0.2);
            }
            
            // 確認音效
            playConfirmSound() {
                this.playBeep(800, 100);
                setTimeout(() => this.playBeep(1000, 100), 100);
            }
        }

        // 初始化音效系統
        const soundEffects = new SoundEffects();





        function formatDuration(ms) {
            const totalSeconds = Math.max(0, Math.round(ms / 1000));
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;
            if (minutes === 0) {
                return `${seconds} 秒`;
            }
            return `${minutes} 分 ${seconds.toString().padStart(2, '0')} 秒`;
        }

        // ===== 測試腳本 =====
        const testScenarios = [
            {
                name: '基本肩膀按摩',
                input: '幫我按摩肩膀',
                expected: {
                    bodyPart: '肩膀',
                    hasStructuredResponse: true
                }
            },
            {
                name: '詳細指令',
                input: '幫我輕柔地按摩背部5分鐘',
                expected: {
                    bodyPart: '背部',
                    intensity: '輕柔',
                    duration: 5
                }
            },
            {
                name: '症狀描述',
                input: '我肩膀好痛',
                expected: {
                    bodyPart: '肩膀',
                    hasRecommendation: true
                }
            },
            {
                name: '緊急停止',
                input: '停止',
                expected: {
                    emergency: true
                }
            },
            {
                name: '模糊請求',
                input: '幫我按一下',
                expected: {
                    needsClarification: true
                }
            }
        ];

        async function runTests() {
            console.log('🧪 開始測試護理 AI...\n');
            
            for (const scenario of testScenarios) {
                console.log(`📝 測試: ${scenario.name}`);
                console.log(`   輸入: "${scenario.input}"`);
                
                const command = commandParser.parse(scenario.input);
                console.log('   解析結果:', command);
                
                // 驗證預期結果
                let passed = true;
                if (scenario.expected.bodyPart && command.bodyPart !== scenario.expected.bodyPart) {
                    console.log(`   ❌ 部位不匹配: 期望 ${scenario.expected.bodyPart}, 得到 ${command.bodyPart}`);
                    passed = false;
                }
                if (scenario.expected.emergency && !command.emergency) {
                    console.log(`   ❌ 未識別為緊急停止`);
                    passed = false;
                }
                
                if (passed) {
                    console.log('   ✅ 測試通過\n');
                } else {
                    console.log('   ❌ 測試失敗\n');
                }
            }
            
            console.log('🎉 測試完成');
        }

        // ===== 調試系統 =====
        let debugMode = false;

        function debugLog(category, message, data = null) {
            if (!debugMode) return;
            
            const timestamp = new Date().toLocaleTimeString();
            const style = {
                'parse': 'color: #4A90E2; font-weight: bold;',
                'safety': 'color: #E74C3C; font-weight: bold;',
                'ai': 'color: #52C89F; font-weight: bold;',
                'command': 'color: #F39C12; font-weight: bold;',
                'info': 'color: #5D6D7E;'
            };
            
            console.log(`%c[${timestamp}] [${category.toUpperCase()}]`, style[category] || style.info, message);
            if (data) {
                console.log('  📊 數據:', data);
            }
        }

        // 添加動畫樣式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInFromRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);

        async function sendRobotCommand(endpoint, payload = {}) {
            try {
                const response = await fetch(`${API_URL}/massage/${endpoint}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: Object.keys(payload).length ? JSON.stringify(payload) : undefined
                });

                if (!response.ok) {
                    const text = await response.text();
                    throw new Error(text || `HTTP ${response.status}`);
                }
                return true;
            } catch (error) {
                console.warn(`⚠️ Massage API ${endpoint} 失敗:`, error);
                return false;
            }
        }

        // 模擬按摩執行（用於測試，實際部署時替換為真實的機械臂控制）
        async function simulateMassageExecution(command) {
            debugLog('command', '開始模擬按摩執行', command);
            
            // 這裡將來會替換為真實的機械臂通訊代碼
            // await sendToRobot(command);
            
            console.log('🤖 [模擬] 按摩執行中...', {
                bodyPart: command.bodyPart,
                action: command.action,
                intensity: command.intensity,
                duration: command.duration
            });
            
            return new Promise(resolve => {
                setTimeout(resolve, 1000); // 模擬延遲
            });
        }

        // 成就檢查系統
        function checkAndUnlockAchievements(command) {
            const history = safetyChecker.operationHistory;
            
            // 按摩達人：完成 5 次按摩
            if (history.length >= 5) {
                unlockBadge('massageExpert', '⭐', 10);
            }
            
            // 放鬆大師：使用過所有動作類型
            const usedActions = new Set(history.map(op => op.action));
            if (usedActions.size >= 4) {
                unlockBadge('relaxationMaster', '🧘', 10);
            }
            
            // 健康守護者：連續 3 天使用
            const uniqueDays = new Set(
                history.map(op => new Date(op.timestamp).toDateString())
            );
            if (uniqueDays.size >= 3) {
                unlockBadge('wellnessGuardian', '❤️', 10);
            }
            
            // 夜間護理：晚上 8 點後使用
            const hour = new Date().getHours();
            if (hour >= 20 || hour <= 6) {
                unlockBadge('nightCare', '🌙', 10);
            }
        }

        // ========= boot =========
        document.addEventListener('DOMContentLoaded', async () => {
            try {
                await detectAvailablePort();
            } catch(e) {
                console.warn('detectAvailablePort 失敗，使用預設 API_URL：', e);
            }
            await loadWeather();
        });
